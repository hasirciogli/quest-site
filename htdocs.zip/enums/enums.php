<?php


enum FF_BANK_ID_ENUMERATIONS {
    case BANK_ID_QNB_FINANSBAN;
}