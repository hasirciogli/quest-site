<?php

namespace AuthModel;

use DATABASE\FFDatabase;

class AuthModel extends FFDatabase
{

}