<?php

namespace GatesController;

use DATABASE\FFDatabase;
use PDO;
use Router\Router;
use SessionController\SessionController;

class OwnerController
{

}