create table data_log
(
    id       int auto_increment
        primary key,
    header   varchar(255)  not null,
    body     text          not null,
    log_type int default 0 null
);

create table payment_gates
(
    gate_id    int auto_increment
        primary key,
    bank_name  varchar(255) charset utf8mb3                 null,
    status     enum ('active', 'passive') default 'passive' not null,
    image_link text                                         null,
    param_keys text                                         null,
    req_keys   text                                         null,
    bank_id    int                                          not null,
    test_mode  tinyint(1)                 default 0         null,
    constraint payment_gates_bank_id_uindex
        unique (bank_id)
);

create table payment_requests
(
    id               int auto_increment
        primary key,
    price            double                                                                                    default 1                 null,
    currency_unit    int                                                                                       default 949               null,
    ip_address       varchar(255)                                                                              default 'unmetered'       null,
    status           enum ('confirmed', 'waiting', 'refused', 'refunded', 'cancelled', 'blocked', 'no action') default 'no action'       null,
    created_at       timestamp                                                                                 default CURRENT_TIMESTAMP null,
    updated_at       timestamp                                                                                 default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP,
    balance_status   enum ('valid', 'waiting', 'blocked')                                                      default 'waiting'         null,
    x_data           varchar(255)                                                                                                        null,
    payment_type     enum ('link', 'api', 'bank')                                                              default 'link'            null,
    owner_user_id    int                                                                                       default 1                 null,
    response_data    varchar(255)                                                                                                        null,
    bank_id          int                                                                                       default 1                 null,
    is_silent        int                                                                                       default 0                 null,
    created_at_odate timestamp                                                                                 default CURRENT_TIMESTAMP not null,
    temp_cvv         varchar(255)                                                                              default '-1'              not null,
    bank_payment_id  varchar(255)                                                                              default '-1'              not null
);

create table sessions
(
    id     varchar(32)  not null
        primary key,
    access int unsigned null,
    data   text         null
);

create table site_data
(
    maintenance_mode     int default 1 not null,
    default_payment_gate int default 1 not null
);

create table users
(
    id                  int auto_increment
        primary key,
    name                varchar(255)                                                                                  not null,
    email               varchar(255) collate utf8mb4_unicode_ci                                                       not null,
    password            text collate utf8mb4_unicode_ci                                                               not null,
    birthday            date                                                                                          null,
    email_state         enum ('confirmed', 'waiting', 'sent', 'blocked') collate utf8mb4_unicode_ci default 'waiting' not null,
    confirmed_balance   double(12, 2)                                                               default 0.00      not null,
    unconfirmed_balance double(15, 2)                                                               default 0.00      not null,
    type                enum ('admin', 'user') collate utf8mb4_unicode_ci                           default 'user'    not null,
    created_at          timestamp                                                                                     null,
    updated_at          timestamp                                                                                     null,
    api_key             varchar(255) collate utf8mb4_unicode_ci                                                       null,
    api_secret          varchar(255) collate utf8mb4_unicode_ci                                                       null,
    percent_per_payment double                                                                      default 2.99      not null,
    cost_per_payment    double                                                                      default 0.29      not null,
    mail_conf_key       varchar(255)                                                                                  not null,
    website_limit       int                                                                         default 10        not null,
    phone               varchar(255)                                                                                  not null,
    constraint users_email_unique
        unique (email)
)
    charset = utf8mb3;

create table websites
(
    id                   int auto_increment
        primary key,
    domain               varchar(255)                                                                          not null,
    owner_id             int                                                                                   not null,
    status               enum ('waiting', 'refused', 'active', 'blocked', 'owner_check') default 'owner_check' not null,
    review_request_count int                                                             default 1             not null,
    callback_url         text                                                                                  null,
    owner_check_count    int                                                             default 1             not null,
    site_ssl             enum ('yes', 'no')                                              default 'no'          not null
);

