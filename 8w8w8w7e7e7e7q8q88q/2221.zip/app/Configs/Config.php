<?php

define("configs_site_rootfolder"    , $_SERVER["DOCUMENT_ROOT"]);

define("configs_site_version"    , "1.1");


define("configs_db_host"            , "localhost");
define("configs_db_username"        , "root");
define("configs_db_name"            , "tahsilath");
define("configs_db_password"        , "1234");

define("configs_mail_host"          , "mail.hsrcpay.com");
define("configs_mail_username"      , "admin@hsrcpay.com");
define("configs_mail_from"          , "admin@hsrcpay.com");
define("configs_mail_sender"        , "hsrcpay.com");
define("configs_mail_port"          , 587);
define("configs_mail_password"       , "1478963254789632547819Aaaddfewjkd");


define("configs_host_domain"            , "localhost");
define("configs_host_ssl"               , "http");


define("configs_payment_backtr"               , "KSKBODPTR_wkdnIIOT_");


define("configs_api_prefix"       , "api");

define("configs_framework_version"       , "1.0");


define("framework_is_debug_mode"       , true);

?>