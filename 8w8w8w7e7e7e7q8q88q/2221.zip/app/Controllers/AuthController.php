<?php

namespace AuthController;

use AuthModel\AuthModel;
use FCrypter\FCrypter;
use SessionController\SessionController;
use UserController\UserController;

class AuthController extends AuthModel
{
    private static $authedUserUID = null;

    public static function initializeAuthlib($uid){
        AuthController::$authedUserUID = $uid;
    }

    public static function isLogged(){
        $ACSC = new SessionController();
        $returnval = $ACSC->Get("usersession_is_loggedin");
        $ACSC = null;

        if ($returnval){
            return true;
        }
        else{
            return false;
        }
    }

    public static function isAdmin(){
        if(!AuthController::isLogged())
            return false;

        $iaUser = AuthController::getUserData();

        if ($iaUser[0])
        {
            if(isset($iaUser[1]["type"]) && $iaUser[1]["type"] == "admin")
                return true;
            else
                return false;
        }
        else{
            return false;
        }
    }

    public static function getUserData(){
        if(!AuthController::isLogged())
            return false;

        $ACSC = new SessionController();
        $uid = $ACSC->Get("usersession_is_id");
        $ACSC = null;

        return UserController::get()->GetUserData($uid);
    }

    public static function passwordCheck($password){
        if(!AuthController::isLogged())
            return false;

        $ACSC = new SessionController();
        $uid = $ACSC->Get("usersession_is_id");
        $ACSC = null;

        $result = UserController::get()->GetUserData($uid);

        if(!$result[0])
            return false;

        if (!$result[1]["password"])
            return false;

        if (FCrypter::get()->getEncrypt($password) == $result[1]["password"])
            return true;
        else
            return false;
    }

    public static function getUserNameFromNavbar(){
        if(!AuthController::isLogged())
            return false;

        $ACSC = new SessionController();
        $uid = $ACSC->Get("usersession_is_id");
        $ACSC = null;

        $result = UserController::get()->GetUserData($uid);

        if(!$result[0])
            return false;

        $name = $result[1]["name"];

        if (strlen($result[1]["name"]) > 18){
            $name = substr($name, 0, 18);
            return [$name."..." , $result[1]["name"]];
        }else{
            return [$result[1]["name"], $result[1]["name"]];
        }

    }

    public static function getUserID(){
        $result = AuthController::getUserData();

        if (!$result)
            return null;

        if (!$result[0])
            return null;

        if (!$result[1])
            return null;

       return $result[1]["id"];
    }
}