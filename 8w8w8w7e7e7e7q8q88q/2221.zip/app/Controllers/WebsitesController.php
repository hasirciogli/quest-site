<?php

namespace WebsitesController;

use AuthController\AuthController;
use Router\Router;
use SessionController\SessionController;
use UserController\UserController;

class WebsitesController extends \WebsitesModel\WebsitesModel
{

    public function getUserWebsites($get_type = null){
        $uid = AuthController::getUserID();
        if (!$uid)
            return false;
        else
            return $this->_getUserWebsites($uid, $get_type);
    }


    public function addUserWebsite($domain, $callback){
        $uid = AuthController::getUserID();
        if (!$uid)
            return false;
        else
            return $this->_addUserWebsites($domain, $callback, $uid);
    }

    public function removeUserWebsite($domain){
        $uid = AuthController::getUserID();

        if (!$uid)
            return false;
        else
            return $this->_removeUserWebsites($domain, $uid);
    }

    public function updateUserWebsite($id, $old_domain, $new_domain, $new_callback){
        $uid = AuthController::getUserID();

        if (!$uid)
        {
            $smc = new SessionController();
            $smc->Set("SESSION_WEBSITES_SHOW_ERROR"     , true);
            $smc->Set("SESSION_WEBSITES_ERROR"          , "UPDATE SUCCESS!");
        }
        else
            return $this->_updateUserWebsites($old_domain, $new_domain, $new_callback, $uid);
    }

    public function requestReviewUserWebsite($domain){
        $uid = AuthController::getUserID();

        if (!$uid)
            return false;
        else
            return $this->_requestReviewUserWebsite($domain, $uid);
    }

    public function apiControllerRun($rurl){
        $funcParam = 0;
        function getParam($url, $state){ return explode("/", $url)[$state]; }
        function checkYuri($zName, $url, $state){
            if (explode("/", $url)[$state] == $zName)
                return true;
            else
                return false;
        }

        switch (getParam($rurl, $funcParam))
        {
            case "add":
                if(!$_POST) die("need post :)");

                $domain             = strtolower($_POST["domain"]);
                $domain_callback    = $_POST["domain_callback"];
                $return_callback    = $_POST["callback"];

                $smc = new SessionController();

                if (gethostbyname($domain) == $domain) {
                    $smc->Set("SESSION_WEBSITES_SHOW_ERROR"     , true);
                    $smc->Set("SESSION_WEBSITES_ERROR"          , "DOMAIN DNS NOT FOUND!");
                }
                else{
                    $this->addUserWebsite($domain, $domain_callback);
                }

                Router::Route($return_callback);
                break;


            case "remove":
                if(!$_POST) die("need post :)");

                $domain     = strtolower($_POST["domain"]);
                $callback   = $_POST["callback"];

                $this->removeUserWebsite($domain);

                Router::Route($callback);
                break;

            case "requestreview":
                if(!$_POST) die("need post :)");

                $domain     = strtolower($_POST["domain"]);
                $callback   = $_POST["callback"];

                $this->requestReviewUserWebsite($domain);

                Router::Route($callback);
                break;

            case "update":
                if(!$_POST) die("need post :)");

                $callback               = $_POST["callback"];
                $domain_id              = strtolower($_POST["domain_id"]);
                $old_domain             = strtolower($_POST["old_domain"]);
                $new_domain_name        = strtolower($_POST["new_domain_name"]);
                $new_domain_callback    = $_POST["new_domain_callback"];

                $smc = new SessionController();

                if (gethostbyname($new_domain_name) == $new_domain_name) {
                    $smc->Set("SESSION_WEBSITES_SHOW_ERROR"     , true);
                    $smc->Set("SESSION_WEBSITES_ERROR"          , "DOMAIN DNS NOT FOUND!");
                }else{
                    $this->updateUserWebsite($domain_id, $old_domain, $new_domain_name, $new_domain_callback);
                }

                Router::Route($callback);
                break;

            default:
                die(json_encode([
                    "action" => false,
                    "data"=> [
                        "function" => "websites",
                        "your-ip-adress-recorded" => $_SERVER["REMOTE_ADDR"],
                        "ip-address-info" => "Dont worry. This is our security process. Trust us :) ",
                    ]
                ],JSON_UNESCAPED_UNICODE));
                break;
        }
    }

    public static function get(){
        return new WebsitesController();
    }
}