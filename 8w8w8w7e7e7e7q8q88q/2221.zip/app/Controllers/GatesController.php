<?php

namespace GatesController;

use DATABASE\Database;
use DATABASE\FFDatabase;
use PDO;
use Router\Router;
use SessionController\SessionController;

class GatesController extends FFDatabase
{
    public function getDefaultPaymentGateId(){
        return FFDatabase::cfun()->select("site_data")->run()->get()["default_payment_gate"];
    }

    public function setDefaultPaymentGateId($gate_id){
        FFDatabase::cfun()->update("site_data", [["default_payment_gate", $gate_id]])->run();
    }
    public function getGates(){
        $res = FFDatabase::cfun()->select("payment_gates")->where("status", "active")->run()->getAll();


        if ($res == "no-result"){
            return 0;
        }else if($res == false)
            return 0;
        else
            return $res;
    }

    public function getGate($gate_id){
        $res = FFDatabase::cfun()->select("payment_gates")->where("gate_id", $gate_id)->run()->get();

        if ($res == "no-result"){
            return false;
        }else if($res == false)
            return false;
        else
            return $res;
    }

    public function getGateFromPayment($payment_id){
        $bank_id = FFDatabase::cfun()->select("payment_requests")->where("id", $payment_id)->run()->get()["bank_id"];

        $res = FFDatabase::cfun()->select("payment_gates")->where("bank_id", $bank_id)->run()->get();

        if ($res == "no-record"){
            return false;
        }else if($res == false)
            return false;
        else
            return $res;
    }

    public function apiControllerRun($rurl){
        $funcParam = 0;
        function getParam($url, $state){ return explode("/", $url)[$state]; }
        function checkYuri($zName, $url, $state){
            if (explode("/", $url)[$state] == $zName)
                return true;
            else
                return false;
        }

        switch (getParam($rurl, $funcParam))
        {
            case "update":
                if(!$_POST) die("need post :)");

                $gate_id            = $_POST["gate_id"];
                $keys = null;
                $return_callback    = $_POST["callback"];

                $result = FFDatabase::cfun()->select("payment_gates")->where("gate_id", $gate_id)->run()->get();

                if($result && $result != "no-record"){
                    $cgb = true;

                    $dDatra = null;

                    foreach (json_decode($result["req_keys"]) as $item){
                        $dDatra[$item] = $_POST["update_gate_" . $item];
                    }


                    $result = FFDatabase::cfun()->update("payment_gates", [["param_keys", json_encode($dDatra, JSON_UNESCAPED_UNICODE)]])->where("gate_id", $gate_id)->run();

                }

                Router::Route($return_callback);
                break;

            case "set_as_default":
                if(!$_POST) die("need post :)");

                $gate_id            = $_POST["gate_id"];
                $keys = null;
                $return_callback    = $_POST["callback"];

                $this->setDefaultPaymentGateId($gate_id);

                Router::Route($return_callback);
                break;

            default:
                die(json_encode([
                    "action" => false,
                    "data"=> [
                        "function" => "websites",
                        "your-ip-adress-recorded" => $_SERVER["REMOTE_ADDR"],
                        "ip-address-info" => "Dont worry. This is our security process. Trust us :) ",
                    ]
                ],JSON_UNESCAPED_UNICODE));
                break;
        }
    }

    public static function createClassInstance(){
        return new GatesController();
    }
}