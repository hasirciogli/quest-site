<?php

namespace ResponseBankController;

use DATABASE\FFDatabase;
use Router\Router;

class ResponseBankController
{
    public function apiControllerRun($rurl){
        $funcParam = 0;
        function getParam($url, $state){ return explode("/", $url)[$state]; }
        function checkYuri($zName, $url, $state){
            if (explode("/", $url)[$state] == $zName)
                return true;
            else
                return false;
        }

        switch (getParam($rurl, $funcParam))
        {
            case "2":
                include $_SERVER["DOCUMENT_ROOT"] . "/app/pgates/2/payment.php";
                break;

            case "3":
                include $_SERVER["DOCUMENT_ROOT"] . "/app/pgates/3/payment.php";
                break;

            case "4":
                include $_SERVER["DOCUMENT_ROOT"] . "/app/pgates/4/payment.php";
                break;

            case "5":
                include $_SERVER["DOCUMENT_ROOT"] . "/app/pgates/5/payment.php";
                break;

            case "6":
                include $_SERVER["DOCUMENT_ROOT"] . "/app/pgates/6/payment.php";
                break;

            case "1":
                include $_SERVER["DOCUMENT_ROOT"] . "/app/pgates/1/payment.php";
                break;

            default:
                die(json_encode([
                    "action" => false,
                    "data"=> [
                        "function" => "websites",
                        "your-ip-adress-recorded" => $_SERVER["REMOTE_ADDR"],
                        "ip-address-info" => "Dont worry. This is our security process. Trust us :) ",
                    ]
                ],JSON_UNESCAPED_UNICODE));
                break;
        }
    }

    public static function createClassInstance(){
        return new ResponseBankController();
    }
}