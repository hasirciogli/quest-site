<?php

namespace PaymentRequsetsController;
use AuthController\AuthController;
use DATABASE\FFDatabase;
use \PaymentRequsetsModel\PaymentRequsetsModel;
use Router\Router;

class PaymentRequsetsController extends PaymentRequsetsModel
{
    public function GetPaymentRequests()
    {
        return $this->_getPaymentRequests();
    }

    public function GetUserOfPayment($user_id)
    {
        return $this->_getUserOfPayment($user_id);
    }

    public function GetPaymentOfId($payment_id)
    {
        return $this->_getPaymentOfId($payment_id);
    }

    public function GetLast10PaymentRequests()
    {
        return $this->_getLast10PaymentRequests();
    }

    public function GetUserPaymentRequests()
    {
        return $this->_getUserPaymentRequests();
    }

    public function GetUserLast10PaymentRequests()
    {
        return $this->_getUserLast10PaymentRequests();
    }

    public function GetPaymentMoneyUnit($unit){
        switch ($unit)
        {
            case "949":
                return "TL";
            case "643":
                return "RUB";
            case "826":
                return "GBP";
            case "840":
                return "USD";
            case "978":
                return "EUR";
            default:
                return "TL";
        }
    }



    public function GetTodayCash(){
        return $this->_getTodayCash();
    }

    public function GetDenizbankTodayCash($formatted = null){
        return $this->_getDenizbankTodayCash($formatted);
    }

    public function GetFinansbankTodayCash($formatted = null){
        return $this->_getFinansbankTodayCash($formatted);
    }

    public function GetIngbankTodayCash($formatted = null){
        return $this->_getIngbankTodayCash($formatted);
    }

    public function GetSekerbankTodayCash($formatted = null){
        return $this->_getSekerbankTodayCash($formatted);
    }

    public function GetVakifbankTodayCash($formatted = null){
        return $this->_getVakifbankTodayCash($formatted);
    }

    public function GetCompletedPayments(){
        return $this->_getCompletedPayments();
    }

    public function GetFailedPayments(){
        return $this->_getFailedPayments();
    }

    public function GetChartData(){
        return $this->_getChartData();
    }

    public function apiControllerRun($rurl){
        $funcParam = 0;
        function getParam($url, $state){ return explode("/", $url)[$state]; }
        function checkYuri($zName, $url, $state){
            if (explode("/", $url)[$state] == $zName)
                return true;
            else
                return false;
        }

        switch (getParam($rurl, $funcParam))
        {
            case "add":
                if(!$_POST) Router::Route("login");

                $return_callback    = $_POST["callback"];

                $result = FFDatabase::cfun()->insert("payment_requests", [
                    [
                        "price",
                        $_POST["price"]
                    ],
                    [
                        "currency_unit",
                        $_POST["currency_unit"]
                    ],
                    [
                        "ip_address",
                        $_SERVER["REMOTE_ADDR"]
                    ],
                    [
                        "payment_type",
                        "bank"
                    ],
                    [
                        "bank_id",
                        $_POST["gate_bank_id"]
                    ],
                    [
                        "owner_user_id",
                        AuthController::getUserID()
                    ]
                ])->run();

                Router::Route($return_callback);
                break;

            case "refund":
                if(!$_POST) Router::Route("login");

                $return_callback        = $_POST["callback"];

                $internal_payment_id    = $_POST["internal_payment_id"];

                $ths_payment_data = FFDatabase::cfun()->select("payment_requests")->where("id", $internal_payment_id)->run()->get();

                $bank_payment_id        = $ths_payment_data["bank_payment_id"];

                $internal_bank_id       = $ths_payment_data["bank_id"];

                switch ($internal_bank_id){
                    /*

                    case 1:
                        require configs_site_rootfolder . "/app/pgates/" . $internal_bank_id. "/refund.php";
                        \DENIZBankRefunder::cfun()->CreateRefund($internal_payment_id, $bank_payment_id, $ths_payment_data["price"]);
                        break;

                    */

                    case 5:
                        require configs_site_rootfolder . "/app/pgates/" . $internal_bank_id. "/refund.php";
                        \QNBFINANSBankRefunder::cfun()->CreateRefund($internal_payment_id, $bank_payment_id, $ths_payment_data["price"]);
                        break;

                    default:
                        header("Content-Type: Application/Json");
                        header("Refresh: 1, /");
                        die(json_encode([
                            "action" => false,
                            "data" => [
                                "Exposdiend" => "Şuanlık sadece QNB Finansbank için iade oluşturuabilir veya kontrol edebilirsiniz.",
                                "function" => "Payment Refund To Bank a default case in switch",
                                "your-ip-adress-recorded" => $_SERVER["REMOTE_ADDR"],
                                "ip-address-info" => "Dont worry. This is our security process. Trust us :) "
                            ]
                        ], JSON_UNESCAPED_UNICODE));
                        break;
                }




                Router::Route($return_callback);

                die();

                break;

            default:
                die(json_encode([
                    "action" => false,
                    "data"=> [
                        "function" => "websites",
                        "your-ip-adress-recorded" => $_SERVER["REMOTE_ADDR"],
                        "ip-address-info" => "Dont worry. This is our security process. Trust us :) ",
                    ]
                ],JSON_UNESCAPED_UNICODE));
                break;
        }
    }

    public static function get(){
        return new PaymentRequsetsController();
    }
}