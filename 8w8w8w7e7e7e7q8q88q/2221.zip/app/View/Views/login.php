<?php

if(\AuthController\AuthController::isLogged())
    \Router\Router::Route("dashboard");

$post_err = isset($_SESSION["SESSION_LOGIN_ERROR"]) ? $_SESSION["SESSION_LOGIN_ERROR"] : null;
$_SESSION["SESSION_LOGIN_ERROR"] = null;

?>

<div class="min-inner-height flex w-full justify-center items-center p-3">
    <form action="/api/user/login" method="post" class="flex rounded-lg flex-col w-full md:w-[400px] p-3 mx-auto mt-5 bg-white shadow-md shadow-slate-300">
        <?php if($post_err) {?>
            <div class="w-full flex items-center bg-red-400 min-h-10 rounded p-3 text-white text-md font-extrabold">
                <?php echo $post_err; ?>
            </div>
        <?php } ?>
        <h1 class="text-2xl text-gray-700 flex items-center justify-center p-2 mb-3 font-bold">LOGIN</h1>
        <p class="text-gray-700 text-sm">Email</p>
        <input type="email" name="email" placeholder="Email" class="h-[40px] rounded mb-2">
        <p class="text-gray-700 text-sm">Password</p>
        <input type="password" name="password" placeholder="Password" class="h-[40px] rounded mb-2">
        <div class="flex justify-center mt-3">
            <input type="submit" name="sbm_btn" value="Enter the panel" class="w-full font-arial font-bold text-slate-100 hover:text-white h-[35px] bg-blue-400 rounded hover:cursor-pointer hover:bg-blue-600 duration-200 ease-in-out">
        </div>

        <div class="w-full border-t mt-5 pt-3 flex justify-center items-center font-arial text-gray-700">
            <a href="/register">You don't have account ? register here</a>
        </div>
    </form>
</div>