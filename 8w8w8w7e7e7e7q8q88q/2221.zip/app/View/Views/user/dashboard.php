<?php

$AuthedUserData = \AuthController\AuthController::getUserData();

if( $AuthedUserData[1]["email_state"] == "blocked" )
    die('Your Email AddressBlocked <a href="/logout"> Çıkış Yap!</a>');

if($AuthedUserData[1]["email_state"] != "confirmed" ){
?>

    <div class="w-full h-[100px] flex fixed z-[200] bg-red-400 font-semibold text-2xl text-slate-100 justify-center items-center top-0 left-0">
        Please verify your email address. Email has been sent to <?php echo $AuthedUserData[1]["email"]; ?> <span class="ml-3"> or </span><a class="ml-3 hover:text-blue-600 duration-200" href="/logout">Log out</a>
    </div>


<?php }

require $_SERVER["DOCUMENT_ROOT"] . "/app/View/Views/user/includes/nav.php";

$switchUri = \Router\Router::AnalyzeMiddlewareUri()[1] ?? "null";
$switchUri2 = \Router\Router::AnalyzeMiddlewareUri()[2] ?? "null";

switch ($switchUri){
    case "profile":
        require $_SERVER["DOCUMENT_ROOT"] . "/app/View/Views/user/profile.php";
        break;

    case "settings":
        require $_SERVER["DOCUMENT_ROOT"] . "/app/View/Views/user/settings.php";
        break;

    case "gates":
        switch ($switchUri2){
            case "update":
                require $_SERVER["DOCUMENT_ROOT"] . "/app/View/Views/user/funcs/ugates.php";
                break;
            default:
                require $_SERVER["DOCUMENT_ROOT"] . "/app/View/Views/user/gates.php";
                break;
        }
        break;

    default:
        require $_SERVER["DOCUMENT_ROOT"] . "/app/View/Views/user/main.php";
        break;

}


require $_SERVER["DOCUMENT_ROOT"] . "/app/View/Views/user/includes/footer.php";
?>