<?php
$loadd = false;

if (!$_POST)
    $loadd = true;

if (!isset($_POST["gate_id"]) || $_POST["gate_id"] == "")
    $loadd = true;

if ($loadd)
{
    \Router\Router::Route("dashboard/gates");
    return;
}


$gate_id = $_POST["gate_id"];

$result = \DATABASE\FFDatabase::cfun()->select("payment_gates")->where("gate_id", $gate_id)->run()->get();


if(!$result || $result == "no-record")
    \Router\Router::Route("dashboard/gates");

?>

<div class="container mx-auto mt-5 p-3">
    <form action="/api/gates/update" method="post" class="w-full mx-auto sm:w-[450px] flex flex-col">
        <span class="w-full flex h-10 items-center justify-center font-medium text-xl bg-gray-400 rounded-sm text-slate-100"><?php echo $result["bank_name"]; ?></span>
        <input type="text" class="hidden" name="gate_id" value="<?php echo $gate_id; ?>">
        <input type="text" class="hidden" name="callback" value="dashboard/gates">
        <?php
        if ($result["req_keys"] != null && $result["req_keys"] != "")
        {
            foreach (json_decode($result["req_keys"]) as $item) { ?>

                <span class="mt-2"><?php echo $item; ?></span>
                <input type="text" class="w-full h-[40px] p-2 text-gray-700 rounded-sm border-1 border-gray-300 shadow-md shadow-gray-200" placeholder="<?php echo $item;?>" value="<?php echo $result["param_keys"] != "" ? json_decode($result["param_keys"])->{$item} : "";?>" name="update_gate_<?php echo $item;?>">

            <?php }
        } ?>

        <input type="submit" class="w-full h-[50px] bg-blue-500 text-slate-200 hover:cursor-pointer hover:text-white hover:bg-blue-700 duration-200 ease-in-out mt-3 rounded-sm shadow-md shadow-gray-300" value="Güncelle">
        <a href="/dashboard/gates">
            <input type="button" class="w-full h-[50px] bg-red-500 text-slate-200 hover:cursor-pointer hover:text-white hover:bg-red-600 duration-200 ease-in-out mt-3 rounded-sm shadow-md shadow-gray-300" value="İptal Et">
        </a>
    </form>
</div>
