<?php
if (\AuthController\AuthController::isLogged())
    die("BETA OLARAK YAPIM AŞAMASINDADIR!");
else
    \Router\Router::Route("");