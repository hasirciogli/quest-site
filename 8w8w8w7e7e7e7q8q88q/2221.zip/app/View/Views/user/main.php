<?php

use GatesController\GatesController;
use PaymentRequsetsController\PaymentRequsetsController;

$prc_instance = PaymentRequsetsController::get();

?>

<div class="w-full min-h-screen">
    <div class="z-[100] overflow-hidden container rounded mt-0 md:mt-3 mb-3 mx-auto">
        <h2 class="m-3 text-lg font-semibold text-gray-700">Bugün'ün pos kazançları</h2>
        <div class="w-full flex flex-col md:flex-row">

            <card class="rounded-lg w-full overflow-hidden shadow-md h-[100px] bg-white flex flex-col m-3 p-3 pt-1">
                <h1 class="font-bold text-gray-700 border-b border-slate-300">Denizbank</h1>
                <div class="flex text-xl sm:text-sm md:text-sm lg:text-lg h-full w-full items-center justify-center font-semibold font-mono">
                    <?php echo  $prc_instance->GetDenizbankTodayCash(true) . " TL"; ?>
                </div>
            </card>

            <card class="rounded-lg w-full overflow-hidden shadow-md h-[100px] bg-white flex flex-col m-3 p-3 pt-1">
                <h1 class="font-bold text-gray-700 border-b border-slate-300">Finansbank</h1>
                <div class="flex text-xl sm:text-sm md:text-sm lg:text-lg h-full w-full items-center justify-center font-semibold font-mono">
                    <?php echo  $prc_instance->GetFinansbankTodayCash(true) . " TL"; ?>
                </div>
            </card>

            <card class="rounded-lg w-full overflow-hidden shadow-md h-[100px] bg-white flex flex-col m-3 p-3 pt-1">
                <h1 class="font-bold text-gray-700 border-b border-slate-300">INGBank</h1>
                <div class="flex text-xl sm:text-sm md:text-sm lg:text-lg h-full w-full items-center justify-center font-semibold font-mono">
                    <?php echo  $prc_instance->GetIngbankTodayCash(true) . " TL"; ?>
                </div>
            </card>

            <card class="rounded-lg w-full overflow-hidden shadow-md h-[100px] bg-white flex flex-col m-3 p-3 pt-1">
                <h1 class="font-bold text-gray-700 border-b border-slate-300">Şekerbank</h1>
                <div class="flex text-xl sm:text-sm md:text-sm lg:text-lg h-full w-full items-center justify-center font-semibold font-mono">
                    <?php echo  $prc_instance->GetSekerbankTodayCash(true) . " TL"; ?>
                </div>
            </card>

            <card class="rounded-lg w-full overflow-hidden shadow-md h-[100px] bg-white flex flex-col m-3 p-3 pt-1">
                <h1 class="font-bold text-gray-700 border-b border-slate-300">Vakıfbank</h1>
                <div class="flex text-xl sm:text-sm md:text-sm lg:text-lg h-full w-full items-center justify-center font-semibold font-mono">
                    <?php echo  $prc_instance->GetVakifbankTodayCash(true) . " TL"; ?>
                </div>
            </card>


        </div>
    </div>
    <div class="z-[100] overflow-hidden container min-h-10 rounded mt-0 md:mt-3 mb-3 mx-auto">
        <div class="w-full min-h-[300px] max-h-[800px] md:max-h-[600px] flex flex-col md:flex-row">

            <div class="w-full md:w-1/3 h-[350px] flex justify-center">
                <div class="w-full h-full flex flex-col items-center">
                    <div class="w-full h-[40px] mt-10">
                        <div class="float-left w-11/12 h-full flex justify-center items-center text-3xl font-bold text-gray-700">
                            Yeni Tahsilat
                        </div>
                    </div>

                    <form class="w-full h-[60px] flex items-center flex-col" action="/api/payment/add" method="post">

                        <input type="text" value="dashboard" class="hidden w-full" name="callback">

                        <div class="mt-3 px-5 w-full text-slate-600 flex flex-col mt-5">
                            <span class="text-white">Ödeme Yöntemi:</span>
                            <select name="gate_bank_id" id="tahsilat_add_gate">
                                <?php foreach (GatesController::createClassInstance()->getGates() as $item) { ?>

                                    <option value="<?php echo $item["bank_id"]; ?>"><?php echo $item["bank_name"]; ?></option>

                                <?php } ?>
                            </select>
                        </div>

                        <div class="mt-3 px-5 w-full text-slate-600 mt-5">
                            <span class="text-white">Tutar:</span>
                            <div class="w-full h-10 flex flex-row">
                                <input type="text" placeholder="Tutar" name="price" id="tahsilat_add_tutar" class="w-7/12 mr-full">
                                <div class="w-5/12 flex flex-row justify-end">
                                    <select name="currency_unit" id="tahsilat_add_currency" class="w-10/12">
                                        <option value="949">TL</option>
                                        <option value="643">RUB</option>
                                        <option value="840">USD</option>
                                        <option value="978">EUR</option>
                                        <option value="826">GBP</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="w-full flex justify-center px-5 w-full mt-10">
                            <input type="submit" value="Yeni tahsilat oluştur" class="py-2 px-3 text-white font-semibold min-w-[150px] bg-orange-400 hover:bg-orange-500 duration-200 rounded hover:cursor-pointer">
                        </div>
                    </form>
                </div>
            </div>

            <div class="w-full md:w-2/3 h-full flex flex-col p-3">

                <!--<card class="rounded-lg w-full overflow-hidden shadow-md h-[100px] bg-white flex">
                    <div class="flex flex-row w-full h-full">
                        <div class="flex flex-col w-9/12 h-full">
                            <div class="w-full h-10 font-medium text-gray-700 text-sm md:text-xs lg:text-sm flex items-end pl-2 lg:pl-5 border-b border-gray-300 pb-1 pt-2">
                                Günlük Kazanç
                            </div>

                            <div class="w-full h-full flex items-center pl-3 font-semibold text-gray-800 text-2xl">
                                <?php

                                $prcTodayCashRates = $prc_instance->GetTodayCash();

                                echo $prcTodayCashRates[0];

                                ?>
                                <span class="ml-1">TL</span>
                                <?php

                                $prcTodayCashRates = $prc_instance->GetTodayCash();

                                $ptrExce = "";

                                if ($prcTodayCashRates[1] > 0) {
                                    $ptrColor = "text-green-600";
                                    $ptrExce = "+ %" . $prcTodayCashRates[1];
                                } else if ($prcTodayCashRates[1] < 0) {
                                    $ptrColor = "text-red-600";
                                    $ptrExce = "- %" . $prcTodayCashRates[1];
                                } else if ($prcTodayCashRates[1] == 0) {
                                    $ptrColor = "text-orange-600";
                                    $ptrExce = "%" . $prcTodayCashRates[1];
                                }

                                ?>
                                <span class="ml-3 <?php echo $ptrColor; ?> text-xs font-semibold h-full flex items-center pt-2">
                                <?php echo $ptrExce; ?>
                            </span>
                            </div>
                        </div>

                        <div class="flex flex-col w-3/12 h-full items-center justify-center">
                            <div class="relative w-10/12 flex items-center justify-center">
                                <div class="w-full flex items-center justify-center rounded-md h-[70px] bg-blue-300 blur-sm"></div>
                                <div class="w-full text-white text-3xl absolute flex items-center justify-center rounded-md h-[70px] bg-gradient-to-br from-blue-500 to-blue-700">
                                    <i class="fa-solid fa-turkish-lira-sign"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </card>


                <card class="rounded-lg w-full overflow-hidden shadow-md h-[100px] bg-white flex mt-3">
                    <div class="flex flex-row w-full h-full">
                        <div class="flex flex-col w-9/12 h-full">
                            <div class="w-full h-10 font-medium text-gray-700 text-sm md:text-xs lg:text-sm flex items-end pl-2 lg:pl-5 border-b border-gray-300 pb-1 pt-2">
                                Toplam Başarılı Satış
                            </div>

                            <div class="w-full h-full flex items-center pl-3 font-semibold text-gray-800 text-2xl">
                                <?php

                                $prcTodayCashRates = $prc_instance->GetCompletedPayments();

                                echo $prcTodayCashRates;

                                ?>

                                <span class="ml-1">
                                  TL
                            </span>
                            </div>
                        </div>

                        <div class="flex flex-col w-3/12 h-full items-center justify-center">
                            <div class="relative w-10/12 flex items-center justify-center">
                                <div class="w-full flex items-center justify-center rounded-md h-[70px] bg-green-300 blur-sm"></div>
                                <div class="w-full text-white text-3xl absolute flex items-center justify-center rounded-md h-[70px] bg-gradient-to-br from-green-400 to-green-600">
                                    <i class="fa-solid fa-check-double"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </card>


                <card class="rounded-lg w-full overflow-hidden shadow-md h-[100px] bg-white flex mt-3">
                    <div class="flex flex-row w-full h-full">
                        <div class="flex flex-col w-9/12 h-full">
                            <div class="w-full h-10 font-medium text-gray-700 text-sm md:text-xs lg:text-sm flex items-end pl-2 lg:pl-5 border-b border-gray-300 pb-1 pt-2">
                                Toplam Başarısız Satış
                            </div>

                            <div class="w-full h-full flex items-center pl-3 font-semibold text-gray-800 text-2xl">
                                <?php

                                $prcTodayCashRates = $prc_instance->GetFailedPayments();

                                echo $prcTodayCashRates;

                                ?>

                                <span class="ml-1">
                                  TL
                            </span>
                            </div>
                        </div>

                        <div class="flex flex-col w-3/12 h-full items-center justify-center">
                            <div class="relative w-10/12 flex items-center justify-center">
                                <div class="w-full flex items-center justify-center rounded-md h-[70px] bg-red-400 blur-sm"></div>
                                <div class="w-full text-white text-3xl absolute flex items-center justify-center rounded-md h-[70px] bg-gradient-to-br from-pink-500 to-red-600">
                                    <i class="fa-solid fa-xmark"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </card>-->
                <div class="flex w-full h-[50px] items-center justify-center">
                    <button id="chart-side-style-line" class="button h-[40px] w-[100px] rounded bg-blue-500 duration-300 hover:bg-blue-700 text-white font-bold">
                        Line
                    </button>

                    <button id="chart-side-style-bar" class="button h-[40px] w-[100px] rounded bg-blue-500 duration-300 hover:bg-blue-700 text-white font-bold ml-2">
                        Bar
                    </button>

                    <button id="chart-side-style-pie" class="button h-[40px] w-[100px] rounded bg-blue-500 duration-300 hover:bg-blue-700 text-white font-bold ml-2">
                        Pie
                    </button>
                </div>

                <canvas id="myChart" class="w-full max-h-[550px]"></canvas>


                <script>

                    <?php $bhgkkJJCHDTA = $prc_instance->GetChartData(); ?>


                    const ctx = document.getElementById('myChart');
                    const labels = [
                        "<?php echo $bhgkkJJCHDTA[1][0]; ?>",
                        "<?php echo $bhgkkJJCHDTA[2][0]; ?>",
                        "<?php echo $bhgkkJJCHDTA[3][0]; ?>",
                        "<?php echo $bhgkkJJCHDTA[4][0]; ?>",
                        "<?php echo $bhgkkJJCHDTA[5][0]; ?>",
                        "<?php echo $bhgkkJJCHDTA[6][0]; ?>",
                        "<?php echo $bhgkkJJCHDTA[7][0]; ?>"
                    ];
                    const data = {
                        labels: labels,
                        datasets: [{
                            label: "Kazanç (TL)",
                            data: [
                                "<?php echo $bhgkkJJCHDTA[1][1]; ?>",
                                "<?php echo $bhgkkJJCHDTA[2][1]; ?>",
                                "<?php echo $bhgkkJJCHDTA[3][1]; ?>",
                                "<?php echo $bhgkkJJCHDTA[4][1]; ?>",
                                "<?php echo $bhgkkJJCHDTA[5][1]; ?>",
                                "<?php echo $bhgkkJJCHDTA[6][1]; ?>",
                                "<?php echo $bhgkkJJCHDTA[7][1]; ?>"
                            ],
                            fill: false,
                            tension: 0.1,
                            backgroundColor: [
                                'rgb(131,102,180)',
                                'rgb(128,202,255)',
                                'rgb(224,198,50)',
                                'rgb(67,194,78)',
                                'rgb(210,121,49)',
                                'rgb(53,74,185)',
                                'rgb(61,192,163)',
                            ],
                            borderColor: [
                                'rgb(128,202,255)',
                                'rgb(128,202,255)',
                                'rgb(128,202,255)',
                                'rgb(128,202,255)',
                                'rgb(128,202,255)',
                                'rgb(128,202,255)',
                                'rgb(128,202,255)',
                            ],
                            borderWidth: 1
                        }]
                    };

                    const config = {
                        type: 'line',
                        data: data,
                        options: {
                            legend: {display: false},
                            plugins: {
                                title: {
                                    display: true,
                                    text: 'Son 1 Hafta Raporu',
                                },
                            },
                        },
                    };

                    var myChart = new Chart(ctx, config);

                    $("#chart-side-style-line").click(() => {
                        config.type = "line";
                        myChart.update();
                    });

                    $("#chart-side-style-bar").click(() => {
                        config.type = "bar";
                        myChart.update();
                    });

                    $("#chart-side-style-pie").click(() => {
                        config.type = "pie";
                        myChart.update();
                    });
                </script>

            </div>
        </div>
    </div>

    <div class="container overflow-hidden mx-auto px-2 pb-3 mb-0 md:mb-3">
        <div class="w-full flex flex-row min-h-10 px-2 py-5">
            <div class="w-[350px] text-slate-800 text-2xl md:text-3xl font-semibold">
                Son 100 tahsilat
            </div>
        </div>
        <div class="w-full mx-auto flex flex-col rounded-md overflow-hidden shadow-md shadow-slate-300">
            <div class="w-full grid grid-cols-3 md:grid-cols-10 gap-4 bg-white rounded-t-md border-b border-slate-300 text-black font-bold text-sm">
                <div class="text-center p-3 md:col-span-1">ID</div>
                <div class="text-center p-3 md:col-span-1 hidden md:block">Yetkili Kişi</div>
                <div class="text-center p-3 md:col-span-1">Tutar</div>
                <div class="text-center p-3 md:col-span-1 hidden md:block">Birim</div>
                <div class="text-center p-3 md:col-span-1 hidden md:block">Tarih</div>
                <div class="text-center p-3 md:col-span-2">Durum</div>
                <div class="text-center p-3 md:col-span-1 hidden md:block">Banka</div>
                <div class="text-center p-3 hidden md:block md:col-span-2">İşlemler</div>
            </div>
            <?php

            $p_xjsDATA = PaymentRequsetsController::get()->GetLast10PaymentRequests();

            if ($p_xjsDATA == null) { ?>

                <div class="w-full h-full text-2xl font-bold flex justify-center items-center min-h-[250px]">
                    NO DATA AVAILABLE
                </div>

            <?php } else {

            foreach ($p_xjsDATA as $item)
                {
                    ?>

                <div class="w-full grid grid-cols-3 md:grid-cols-10 gap-4 bg-white text-gray-500 hover:bg-slate-200 hover:text-black duration-200 ease-in-out text-xs">
                    <div class="text-center p-3 md:col-span-1 flex h-full items-center justify-center"><?php echo $item["id"]; ?></div>
                    <div class="text-center p-3 md:col-span-1 hidden md:flex h-full items-center justify-center"><?php echo PaymentRequsetsController::get()->GetUserOfPayment($item["owner_user_id"])["name"]; ?></div>
                    <div class="text-center p-3 md:col-span-1 flex h-full items-center justify-center"><?php echo $item["price"] ?></div>
                    <div class="text-center p-3 md:col-span-1 hidden md:flex h-full items-center justify-center">
                        <?php

                        echo PaymentRequsetsController::get()->GetPaymentMoneyUnit($item["currency_unit"]);

                        ?>
                    </div>
                    <div class="text-center p-3 md:col-span-1 hidden md:flex h-full items-center justify-center"><?php echo $item["created_at"]; ?></div>

                    <?php

                    switch ($item["status"]) {
                        case "confirmed":
                            $tdata = "onaylandı";
                            $color = "bg-green-600";
                            break;

                        case "blocked":
                            $tdata = "bloke edildi";
                            $color = "bg-red-900";
                            break;

                        case "waiting":
                            $tdata = "bekleniyor";
                            $color = "bg-yellow-600";
                            break;

                        case "cancelled":
                            $tdata = "iptal edildi";
                            $color = "bg-red-500";
                            break;
                        case "refused":
                            $tdata = "red edildi";
                            $color = "bg-red-600";
                            break;
                        case "refunded":
                            $tdata = "iade edildi";
                            $color = "bg-red-300";
                            break;
                        default:
                            $tdata = "işlem bekleniyor";
                            $color = "bg-slate-600";
                            break;
                    }

                    ?>

                    <div class="text-center p-3 md:col-span-2 flex h-full items-center justify-center text-slate-200">
                        <span class="<?php echo $color ?> p-1 px-2 rounded overflow-hidden"><?php echo $tdata; ?></span>
                    </div>
                    <div class="text-center p-3 md:col-span-1 hidden md:flex h-full items-center justify-center">
                        <?php

                        if ($item["payment_type"] == "bank") {
                            echo GatesController::createClassInstance()->getGateFromPayment($item["id"])["bank_name"];
                        } else {
                            echo $item["payment_type"];
                        }

                        ?>
                    </div>
                    <div class="text-center p-3 md:col-span-2 hidden md:flex h-full items-center justify-center">

                        <?php

                        switch ($item["status"]) {
                            case "confirmed":
                                ?>

                                <style>
                                    .sola-kaydiran-annimkelskrjkmtos2{
                                        transition: 0.6s;
                                        position: relative;
                                        top: 0;
                                        left: 0px;
                                    }

                                    .sola-kaydiran-annimkelskrjkmtos:hover > .sola-kaydiran-annimkelskrjkmtos2{
                                        position: relative;
                                        top: 0;
                                        left: -100px;
                                    }
                                </style>

                                <div class="bg-red-300 w-[100px] overflow-hidden flex nowrap sola-kaydiran-annimkelskrjkmtos rounded">
                                    <div class="flex nowrap sola-kaydiran-annimkelskrjkmtos2">
                                        <input type="submit" value="Ödendi !" class="px-3 py-2 min-w-[100px] bg-green-700 text-slate-200">

                                        <form action="api/payment/refund" method="post">
                                            <input type="hidden" class="hidden" value="dashboard" name="callback">
                                            <input type="hidden" class="hidden" value="<?php echo $item["id"]; ?>" name="internal_payment_id">
                                            <input type="submit" value="İade Oluştur"
                                                   class="px-3 py-2 min-w-[100px] bg-red-700 duration-200 ease-in-out text-slate-200 hover:text-white hover:cursor-pointer">
                                        </form>
                                    </div>
                                </div>

                                <?php
                                break;

                            case "blocked":
                                $tdata = "bloke edildi";
                                $color = "bg-red-900";
                                break;

                            case "cancelled":
                                ?>

                                <input type="submit" value="Detay"
                                       tahsilat-detay="<?php echo $item["response_data"]; ?>"
                                       class="tahsilat_detay_openbutton px-3 py-2 min-w-[100px] rounded bg-gray-700 duration-200 ease-in-out hover:bg-blue-600 text-slate-200 hover:text-white hover:cursor-pointer">

                                <?php
                                break;
                            case "refused":
                                ?>

                                <input type="submit" value="Detay"
                                       tahsilat-detay="<?php echo $item["response_data"]; ?>"
                                       class="tahsilat_detay_openbutton px-3 py-2 min-w-[100px] rounded bg-gray-700 duration-200 ease-in-out hover:bg-blue-600 text-slate-200 hover:text-white hover:cursor-pointer">

                                <?php
                                break;

                            case "refunded":
                                ?>

                                <input type="button" value="Iade Edildi"
                                       class="px-3 py-2 min-w-[100px] rounded bg-red-300 duration-200 ease-in-out hover:bg-red-600 text-slate-200 hover:text-white hover:cursor-pointer">

                                <?php
                                break;
                            default:
                                ?>

                                <form action="/pay" method="post">
                                    <input type="text" class="hidden" value="<?php echo $item["id"]; ?>" name="p_id">
                                    <input type="submit" value="öde"
                                           class="px-3 py-2 min-w-[100px] rounded bg-blue-500 duration-200 ease-in-out hover:bg-blue-700 text-slate-200 hover:text-white hover:cursor-pointer">
                                </form>

                                <?php
                                break;
                        }

                        ?>
                    </div>
                </div>

            <?php
                }
            }
            ?>

            <!--<div class="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
                <div class="flex-1 flex justify-between sm:hidden">
                    <a href="#" class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"> Previous </a>
                    <a href="#" class="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"> Next </a>
                </div>
                <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                    <div>
                        <p class="text-sm text-gray-700">
                            Showing
                            <span class="font-medium">1</span>
                            to
                            <span class="font-medium">10</span>
                            of
                            <span class="font-medium">97</span>
                            results
                        </p>
                    </div>
                    <div>
                        <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                            <a href="?list_page=1" class="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 hidden md:inline-flex relative items-center px-4 py-2 border text-sm font-medium"> 1 </a>
                            <a href="?list_page=2" class="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 hidden md:inline-flex relative items-center px-4 py-2 border text-sm font-medium"> 2 </a>
                            <a href="?list_page=3" class="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 hidden md:inline-flex relative items-center px-4 py-2 border text-sm font-medium"> 3 </a>
                            <a href="?list_page=4" class="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 hidden md:inline-flex relative items-center px-4 py-2 border text-sm font-medium"> 4 </a>
                            <a href="?list_page=5" class="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 hidden md:inline-flex relative items-center px-4 py-2 border text-sm font-medium"> 5 </a>
                            <a href="?list_page=6" class="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 hidden md:inline-flex relative items-center px-4 py-2 border text-sm font-medium"> 6 </a>
                            <a href="?list_page=7" class="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 hidden md:inline-flex relative items-center px-4 py-2 border text-sm font-medium"> 7 </a>
                            <a href="?list_page=8" class="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 hidden md:inline-flex relative items-center px-4 py-2 border text-sm font-medium"> 8 </a>
                            <a href="?list_page=9" class="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 hidden md:inline-flex relative items-center px-4 py-2 border text-sm font-medium"> 9 </a>
                            <a href="?list_page=10"class="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 hidden md:inline-flex relative items-center px-4 py-2 border text-sm font-medium"> 10 </a>

                            <a href="#" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                <span class="sr-only">Next</span>
                                <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                                </svg>
                        </nav>
                    </div>
                </div>
            </div>-->


        </div>


    </div>
</div>


<div id="tahsilat_detay_table" class="hidden fixed top-0 lef-0 w-full h-screen"
     style="background-color: rgba(20,20,20,0.6);">
    <div class="w-full min-h-screen flex items-center justify-center">
        <div class="flex flex-col p-3 w-full md:w-[400px] min-h-[260px] bg-slate-600 rounded-md overflow-hidden">
            <div class="w-full h-[40px] bg-blue-400 rounded-t">
                <div class="float-left w-11/12 h-full flex justify-center items-center font-medium text-white">Tahsilat
                    Detay
                </div>
                <div class="float-right w-1/12 h-full flex justify-center items-center">
                    <span id="tahsilat_detay_closebutton"
                          class="flex w-full h-full justify-center items-center text-slate-900 hover:text-white hover:cursor-pointer text-2xl">
                        <i class="fa-solid fa-xmark"></i>
                    </span>
                </div>
            </div>

            <div id="tahsilat_detay_area"
                 class="flex text-center rounded-b flex-col w-full h-[220px] bg-blue-800 text-white items-center justify-center">

            </div>
        </div>
    </div>
</div>
