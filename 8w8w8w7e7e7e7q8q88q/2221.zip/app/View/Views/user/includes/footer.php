<?php

return;

?>

<div class="footer w-full min-h-[60px] bg-black text-white text-sm flex items-center justify-center">
    <div class="copyright" align="center">
        <script>
            document.write('&copy;' );
            document.write(' 2021 - ');
            document.write(new Date().getFullYear());
            document.write(' paymentsystem.yokartk.com - All Rights Reserved.');
            document.write('<br/>Last Updated : ');
            document.write(document.lastModified);
        </script>
    </div>
</div>