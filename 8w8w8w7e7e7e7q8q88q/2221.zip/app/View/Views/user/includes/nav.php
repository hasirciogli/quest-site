<?php

$isADMIN = \AuthController\AuthController::isAdmin();

$username_from_navbar = \AuthController\AuthController::getUserNameFromNavbar();

?>
<div class="w-full h-[50px] flex bg-slate-600 mx-auto z-[100]">
    <div class="container h-[50px] mx-auto">
        <div class="float-left flex items-center px-2 h-[50px]">
            <a href="/dashboard">
                <span class="text-slate-100 text-md font-medium flex flex-row items-end ml-2 hidden sm:flex">H-Tahsilat yönetim sistemi</span>
                <span class="text-slate-100 text-md font-medium flex flex-row items-end ml-2 flex sm:hidden">HTYS</span>
            </a>
        </div>
        <div class="float-right flex justify-end h-[50px] w-[200px] md:w-[300px]">
            <div class="flex z-[105] flex-col min-h-[50px] w-full overflow-hidden text-slate-100 <?php if($isADMIN && (false)){ echo "hover:min-h-[210px]"; } else { echo "hover:min-h-[170px]"; }?> hover:shadow-lg shadow-slate-600 hover:bg-slate-100 hover:text-black rounded-b-lg duration-300 drop-down-outline">
                <a class="drop-down-item flex items-center justify-end duration-200 border-b border-slate-600 hover:cursor-pointer"><span class="mr-3"><span class="mr-2 text-sm md:text-lg"><?php echo $username_from_navbar[0]; ?></span> <i class="fa-solid fa-angle-down"></i></span></a>
                <a class="drop-down-item flex items-center justify-end pr-2 hover:pr-4 hover:border-r border-slate-600 duration-200 text-black" href="/dashboard/profile">Profilim</a>
                <?php if($isADMIN && (false)){?><a class="drop-down-item flex items-center justify-end pr-2 hover:pr-4 hover:border-r border-slate-600 duration-200 text-black" href="/admin">Admin Paneli :)</a> <?php } ?>
                <a class="drop-down-item flex items-center justify-end pr-2 hover:pr-4 hover:border-r border-slate-600 duration-200 text-black" href="/dashboard/gates">Poslarım</a>
                <!--<a class="drop-down-item flex items-center justify-end pr-2 hover:pr-4 hover:border-r border-slate-600 duration-200 text-black" href="/dashboard/settings">Genel Ayarlar</a>-->
                <a class="drop-down-item flex items-center justify-end pr-2 hover:pr-4 hover:border-r border-slate-600 duration-200 text-black" href="/logout">Çıkış Yap</a>
            </div>
            <div class="img w-[50px] h-[50px] hidden md:flex justify-center items-center cursor-default">
                <div class="w-[40px] h-[40px] bg-slate-300 flex justify-center items-center rounded-full font-bold text-gray-700">
                    <?php

                    $words = explode(" ", $username_from_navbar[1]);
                    $acronym = "";

                    foreach ($words as $w) {
                        $acronym .= $w[0];
                    }

                    echo $acronym;

                    ?>
                </div>
            </div>
        </div>
    </div>
</div>