<?php




$default_payment_gate_id = \GatesController\GatesController::createClassInstance()->getDefaultPaymentGateId();

$gateControllerInstanceOfGates = \GatesController\GatesController::createClassInstance();

?>

<div class="container mx-auto min-h-[50px] mt-5 p-3">
    <div class="w-full font-bold text-sm md:text-lg text-gray-700 text-lg h-[60px] flex flex-col md:flex-row justify-start md:items-center">
        <?php echo "Varsayılan Ödeme Api'si: " . $gateControllerInstanceOfGates->getGate($default_payment_gate_id)["bank_name"]; ?>
    </div>
    <div class="w-full rounded grid grid-cols-1 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 mt-3">
        <?php foreach ($gateControllerInstanceOfGates->getGates() as $item) { ?>

            <div class="grid-col-1 bg-slate-400 rounded h-[150px] text-white flex flex-col">
                <div class="w-full h-full flex items-center justify-center">
                    <?php echo $item["bank_name"];

                    if ($default_payment_gate_id == $item["gate_id"])
                        echo '<i class="fa-solid fa-check ml-2 text-green-600 text-xl"></i>';
                    else
                        echo '<i class="fa-solid fa-xmark ml-2 text-red-600 text-xl"></i>';

                    ?>
                </div>

                <div class="flex flex-row h-[70px] border-t border-orange-300">
                    <div class="w-4/12 flex items-center justify-start font-medium text-sm px-2">
                        <form action="/dashboard/gates/update" method="post" class="w-full">
                            <input type="text" class="hidden" value="<?php echo $item["gate_id"];?>" name="gate_id">
                            <input type="submit" value="Düzenle" class="w-full h-[30px] text-sm rounded bg-blue-600 hover:bg-blue-800 text-slate-100 hover:text-white duration-200 ease-in-out hover:cursor-pointer">
                        </form>
                    </div>
                    <div class="w-8/12 flex items-center justify-center px-2">
                        <form action="/api/gates/set_as_default" method="post" class="w-full">
                            <input type="text" class="hidden" value="<?php echo $item["gate_id"];?>" name="gate_id">
                            <input type="text" class="hidden" value="dashboard/gates" name="callback">
                            <input type="submit" value="varsayılan işaretle" class="w-full h-[30px] text-sm rounded bg-blue-600 hover:bg-blue-800 text-slate-100 hover:text-white duration-200 ease-in-out hover:cursor-pointer">
                        </form>
                    </div>
                </div>
            </div>

        <?php } ?>
    </div>
</div>