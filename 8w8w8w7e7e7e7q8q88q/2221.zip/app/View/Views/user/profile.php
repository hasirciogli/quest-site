<div class="w-full min-h-screen bg-slate-100">
    <div class="container mx-auto p-3">
        <div class="w-full min-h-10 rounded-b pl-5">
            <span class="text-2xl font-semibold text-slate-700">Profile</span>
        </div>

        <?php

        $smc = new \SessionController\SessionController();

        $if_error_have = $smc->Get("SESSION_PROFILE_SHOW_ERROR");
        if ($if_error_have)
        {
            $profile_error = $smc->Get("SESSION_PROFILE_ERROR");
            $profile_error_type = $smc->Get("SESSION_PROFILE_TYPE");

            $smc->Set("SESSION_PROFILE_SHOW_ERROR"    , false);
            $smc->Set("SESSION_PROFILE_ERROR"          , null);
            $smc->Set("SESSION_PROFILE_TYPE"           , null); ?>


            <div class="w-full text-white flex items-center min-h-[70px] bg-red-400 mt-5 rounded pl-5 <?php echo $profile_error_type; ?>">
                <span class="text-xl font-semibold"><?php echo $profile_error; ?></span>
            </div>


        <?php }
        ?>

        <div class="w-full mt-5 rounded-md shadow-lg shadow-slate-300 bg-slate-500 grid-none md:grid md:grid-cols-2 h-[350px] md:h-[300px]">
            <div class="md:grid-col-1 h-[75px] md:h-[300px] flex items-center justify-center font-semibold text-xl md:text-3xl text-slate-50">
                Password Edit
            </div>

            <div class="md:grid-col-1 h-[275px] md:h-[300px]">
                <form action="/api/user/update/password" method="post" class="flex flex-col w-full h-[275px] md:h-[300px] justify-center">
                    <input type="text" name="callback" value="dashboard/profile" class="w-9/12 mx-auto rounded hidden">
                    <input type="text" placeholder="Old password" name="old_password" class="w-9/12 mx-auto rounded">
                    <input type="text" placeholder="New password" name="new_password" class="w-9/12 mx-auto rounded mt-3">
                    <input type="text" placeholder="Re Password" name="new_repassword" class="w-9/12 mx-auto rounded mt-3">
                    <input type="submit" value="Update Password" class="w-9/12 mx-auto rounded mt-3 bg-blue-700 h-[50px] duration-300 ease-in-out hover:bg-blue-800 text-white font-semibold hover:cursor-pointer">
                </form>
            </div>
        </div>


        <!--<div class="w-full mt-5 rounded-md shadow-lg shadow-slate-300 bg-slate-500 h-[350px] md:h-[300px] flex flex-col p-3 md:p-5">
            <div class="w-full h-[75px] flex items-center justify-center font-semibold text-xl md:text-3xl text-slate-50">
                Api credentials
            </div>
            <div class="w-full h-[75px] flex items-center justify-start font-semibold text-md text-slate-50">
                Api Key: <span class="text-sm ml-2"><?php echo \AuthController\AuthController::getUserData()[1]["api_key"]; ?></span>
            </div>
            <div class="w-full h-[75px] flex items-center justify-start font-semibold text-md text-slate-50">
                Api Secret: <span class="text-sm ml-2"><?php echo \AuthController\AuthController::getUserData()[1]["api_secret"]; ?></span>
            </div>

        </div>-->
    </div>
</div>