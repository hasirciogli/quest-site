<?php

/*die("
    <a href='/login'>Beta sürümünde kayıtlar geçici olarak kapalıdır. 
    Eğer admin hesabınız veya beta kullanıcı hesabınız var ise buradan giriş yapın</a>
");*/

if(\AuthController\AuthController::isLogged())
    \Router\Router::Route("dashboard");

$post_err = isset($_SESSION["SESSION_LOGIN_ERROR"]) ? $_SESSION["SESSION_LOGIN_ERROR"] : null;
$_SESSION["SESSION_LOGIN_ERROR"] = null;

?>
<div class="min-inner-height flex w-full justify-center items-center p-3">
    <form action="/api/user/register" method="post" class="flex rounded flex-col w-full md:w-[400px] p-3 mx-auto mt-5 border bg-slate-600">
        <?php if($post_err) {?>
            <div class="w-full flex items-center  bg-red-400 min-h-10 rounded-sm p-3 text-white text-md font-semibold">
                <?php echo $post_err; ?>
            </div>
        <?php } ?>
        <h1 class="text-2xl text-white flex items-center justify-center p-2 mb-3">REGISTER</h1>
        <p class="text-white text-sm">Full name</p>
        <input type="text" name="fullname" placeholder="Full name"               class="h-[40px] w-full rounded shadow-sm shadow-slate-500 mb-2">
        <p class="text-white text-sm">Email</p>
        <input type="email" name="email" placeholder="Email"                    class="h-[40px] w-full rounded shadow-sm shadow-slate-500 mb-2">
        <p class="text-white text-sm">Birthday</p>
        <input type="date"  name="birthday"                                     class="h-[40px] w-full rounded shadow-sm shadow-slate-500 mb-2">
        <p class="text-white text-sm">Password</p>
        <input type="password" name="password"      placeholder="Password"      class="h-[40px] w-full rounded shadow-sm shadow-slate-500 mb-2">
        <p class="text-white text-sm">Re-Password</p>
        <input type="password" name="repassword"    placeholder="Re-Password"   class="h-[40px] w-full rounded shadow-sm shadow-slate-500 mb-2">
        <div class="flex justify-end">
            <input type="submit" name="sbm_btn" class="w-[100px] font-mono h-[35px] bg-slate-300 rounded shadow-sm shadow-slate-500 hover:cursor-pointer hover:bg-white duration-200 ease-in">
        </div>

        <div class="w-full border-t mt-5 pt-3 flex justify-center items-center font-arial text-white">
            <a href="/login">Do you already have an account? ?</a>
        </div>
    </form>
</div>
