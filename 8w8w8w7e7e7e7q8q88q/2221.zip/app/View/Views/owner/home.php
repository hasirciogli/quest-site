<?php

?>

<form action="/pay" method="post">
    <input type="text" class="hidden" value="178" name="p_id">
    <input type="submit" value="öde" class="px-3 py-2 min-w-[100px] rounded bg-blue-500 duration-200 ease-in-out hover:bg-blue-700 text-slate-200 hover:text-white hover:cursor-pointer">
</form>