<?php

//print_r(\FCrypter\FCrypter::get()->getEncrypt("123456"));
exit;