<?php

use \DATABASE\FFDatabase;
use Router\Router;

class PayControllerInternalClass{
    public static $currency = null;
    public static $price    = null;
    public static $user     = null;

    private function checkParameters(){
        if(!isset($_POST["p_id"]) || $_POST["p_id"] == null || $_POST["p_id"] == "")
        {
            Router::Route("");
            die();
        }
        return $_POST["p_id"];
    }

    private function getPayment($id){
        $v = \DATABASE\Database::sql("SELECT * FROM payment_requests WHERE id=?");
        $x = $v->execute([$id]);
        $result = $v->fetch(PDO::FETCH_ASSOC);

        if($v->rowCount() && $x){
            return $result;
        }
        else{
            Router::Route("");
            die();
            return false;
        }
    }
    private function ifPaymentPayable($payment){
        $_pdata = ['confirmed', 'refused', 'cancelled', 'blocked'];
        foreach($_pdata as $item){
            if($item == $payment["status"]){
                Router::Route("");
                die();
                return false;
                break;
            }
        }
    }

    private function setPaymentToPay($payment){
        $sc = new \SessionController\SessionController();
        $sc->Set("PAYMENT_PAGE_PAY_ID", $payment["id"]);

        $ffd = FFDatabase::cfun();
        $ffd->update("payment_requests", [["status", "waiting"]])->where("id",$payment["id"])->run();
        $ffd = null;
    }

    public function run(){
        $payment_id = $this->checkParameters();
        $payment = $this->getPayment($payment_id);

        $this->ifPaymentPayable($payment);

        $this::$currency    = @\PaymentRequsetsController\PaymentRequsetsController::get()->GetPaymentMoneyUnit($payment["currency_unit"]);
        $this::$price       = @$payment["price"];

        $this::$user = FFDatabase::cfun()->select("users")->where("id", $payment["owner_user_id"])->run()->get();

        $this->setPaymentToPay($payment);
    }

    public function getApiUser($pid){
    }




    public static function get(){
        return new PayControllerInternalClass();
    }
}


$pcic = PayControllerInternalClass::get();

$pcic->run();

$smc = new \SessionController\SessionController();

$client_detail = json_decode(file_get_contents("http://ipinfo.io/" . $_SERVER["REMOTE_ADDR"] . "/json"));


if (strtolower(isset($client_detail->country) ? $client_detail->country : "TR") == "tr"){
    $_translator = [
        "cc-name"       => "Kartın üzerindeki isim",
        "cc-number"     => "Kartınızın numarası",
        "cc-month"      => "Ay",
        "cc-year"       => "Yıl",
        "cc-cvv"       => "G. Kodu",
        "cc-pay"        => "ÖDE",
    ];
}
else{
    $_translator = [
        "cc-name"       => "Credit Card Holder Name:",
        "cc-number"     => "Credit Card Number:",
        "cc-month"      => "Month",
        "cc-year"       => "Year",
        "cc-cvv"        => "CVV",
        "cc-pay"        => "PAY",
    ];
}


$satici_name = PayControllerInternalClass::$user["name"];
$satici_fax = "*";
$satici_adres = "*";
$satici_mail = PayControllerInternalClass::$user["email"];
$satici_telefon = PayControllerInternalClass::$user["phone"];

$alici_name = "*";

?>


<div class="w-full flex flex-col px-3 md:px-0 w-full h-screen bg-gray-300 justify-center items-center">
    <div class="w-full flex flex-col md:w-[450px] min-h-[400px] bg-white rounded-lg shadow-lg shdow-slate-300 p-3">
        <div class="w-[100px] h-[100px] rounded-full bg-blue-600 text-white flex items-center justify-center font-bold mx-auto relative top-[-63px] text-5xl">
            <i class="fa-brands fa-cc-visa"></i>
        </div>
        <form action="/api/rest/payment/pay" method="post" class="flex flex-col mt-[-20px]">
            <input type="hidden" class="hidden" value="<?php echo PayControllerInternalClass::$price; ?>" name="price">
            <label for="ccname" class="text-gray-700 font-bold text-sm"><?php  echo $_translator["cc-name"]; ?></label>
            <input id="ccname" type="text" value="Mustafa Hasırcıoğlu" inputmode="text" autocomplete="cc-name" maxlength="45" placeholder="xxxx xxxx" class="rounded-md mb-4" name="cc_name">


            <label for="ccnumber" class="text-gray-700 font-bold text-sm"><?php  echo $_translator["cc-number"]; ?></label>
            <input id="ccnumber" type="text" value="" inputmode="numeric" pattern="[0-9\s]{13,19}" autocomplete="cc-number" maxlength="19" placeholder="xxxx xxxx xxxx xxxx" class="rounded-md mb-4" name="cc_number">

            <div class="w-full flex flex-row mb-5">
                <div class="item flex flex-col w-4/12">
                    <label class="text-gray-700 font-bold text-sm"><?php  echo $_translator["cc-month"]; ?></label>
                    <input id="cc-month" type="text" value=""  autocomplete="cc-month" maxlength="2" placeholder="xx" class="rounded-md text-center" name="cc_month">
                </div>

                <div class="item flex flex-col w-4/12 ml-2">
                    <label class="text-gray-700 font-bold text-sm"><?php  echo $_translator["cc-year"]; ?></label>
                    <input id="cc-year" type="text" value=""  autocomplete="cc-year" maxlength="2" placeholder="xx" class="rounded-md text-center" name="cc_year">
                </div>

                <div class="item flex flex-col w-2/12 ml-auto">
                    <label class="text-gray-700 font-bold text-sm"><?php  echo $_translator["cc-cvv"]; ?></label>
                    <input id="cc-cvv" type="text" value=""  autocomplete="cc-cvv" maxlength="3" placeholder="xxx" class="rounded-md text-center" name="cc_cvv">
                </div>
            </div>
            <span id="open-sozlesme" class="hover:cursor-pointer mb-5 text-sm font-medium">Mesafeli satış sözleşmesi</span>
            <input type="submit" value="<?php echo $_translator["cc-pay"] . " " . PayControllerInternalClass::$price . " " . PayControllerInternalClass::$currency; ?>" class="w-full rounded-lg bg-blue-600 duration-300 h-[50px] text-xl font-bold text-white hover:bg-blue-800 hover:cursor-pointer">
        </form>
    </div>
</div>


<div class="w-full hidden h-screen z-[600] fixed top-0 left-0 overflow-y-scroll" id="sozlesme-dis">
    <div class="w-full min-h-screen flex justify-center">
        <div class="w-full flex flex-col mx-3 sm:mx-0 md:w-6/12 mt-10 bg-slate-100 min-h-screen rounded-md px-5 pt-0">
            <div class="w-full h-10 flex justify-end">
                <span id="close-sozlesme" class="text-2xl hover:cursor-pointer font-bold hover:text-blue-600 duration-300">X</span>
            </div>

            MESAFELİ SATIŞ SÖZLEŞMESİ <br><br>

            1.TARAFLAR<br><br>

            İşbu Sözleşme aşağıdaki taraflar arasında aşağıda belirtilen hüküm ve şartlar çerçevesinde imzalanmıştır.<br><br>

            A.‘<?php echo $alici_name?>’ ; (sözleşmede bundan sonra “ALICI” olarak anılacaktır)<br><br>

            B.‘<?php echo $satici_name?>’ ; (sözleşmede bundan sonra “SATICI” olarak anılacaktır)<br><br>

            İş bu sözleşmeyi kabul etmekle ALICI, sözleşme konusu siparişi onayladığı takdirde sipariş konusu bedeli ve varsa kargo ücreti, vergi gibi belirtilen ek ücretleri ödeme yükümlülüğü altına gireceğini ve bu konuda bilgilendirildiğini peşinen kabul eder.
            <br><br>

            2.TANIMLAR
            <br>
            İşbu sözleşmenin uygulanmasında ve yorumlanmasında aşağıda yazılı terimler karşılarındaki yazılı açıklamaları ifade edeceklerdir.
            <br><br>
            BAKAN: Gümrük ve Ticaret Bakanı’nı,
            <br><br>
            BAKANLIK: Gümrük ve Ticaret Bakanlığı’nı,
            <br><br>
            KANUN: 6502 sayılı Tüketicinin Korunması Hakkında Kanun’u,
            <br><br>
            YÖNETMELİK: Mesafeli Sözleşmeler Yönetmeliği’ni (RG:27.11.2014/29188)
            <br><br>
            HİZMET: Bir ücret veya menfaat karşılığında yapılan ya da yapılması taahhüt edilen mal sağlama dışındaki her türlü tüketici işleminin konusunu ,
            <br><br>
            SATICI: Ticari veya mesleki faaliyetleri kapsamında tüketiciye mal sunan veya mal sunan adına veya hesabına hareket eden şirketi,
            <br><br>
            ALICI: Bir mal veya hizmeti ticari veya mesleki olmayan amaçlarla edinen, kullanan veya yararlanan gerçek ya da tüzel kişiyi,
            <br><br>
            SİTE: SATICI’ya ait internet sitesini,
            <br><br>
            SİPARİŞ VEREN: Bir mal veya hizmeti SATICI’ya ait internet sitesi üzerinden talep eden gerçek ya da tüzel kişiyi,
            <br><br>
            TARAFLAR: SATICI ve ALICI’yı,
            <br><br>
            SÖZLEŞME: SATICI ve ALICI arasında akdedilen işbu sözleşmeyi,
            <br><br>
            MAL: Alışverişe konu olan taşınır eşyayı ve elektronik ortamda kullanılmak üzere hazırlanan yazılım, ses, görüntü ve benzeri gayri maddi malları ifade eder.
            <br><br><br>

            3.KONU
            <br><br>
            İşbu Sözleşme, ALICI’nın, SATICI’ya ait internet sitesi üzerinden elektronik ortamda siparişini verdiği aşağıda nitelikleri ve satış fiyatı belirtilen ürünün satışı ve teslimi ile ilgili olarak 6502 sayılı Tüketicinin Korunması Hakkında Kanun ve Mesafeli Sözleşmelere Dair Yönetmelik hükümleri gereğince tarafların hak ve yükümlülüklerini düzenler.
            <br><br>
            Listelenen ve sitede ilan edilen fiyatlar satış fiyatıdır. İlan edilen fiyatlar ve vaatler güncelleme yapılana ve değiştirilene kadar geçerlidir. Süreli olarak ilan edilen fiyatlar ise belirtilen süre sonuna kadar geçerlidir.
            <br><br>

            3.SATICI BİLGİLERİ
            <br><br>
            Ünvanı : <?php echo $satici_name?>
            <br><br>
            Adres : <?php echo $satici_adres?>
            <br><br>
            Telefon : <?php echo $satici_telefon?>
            <br><br>
            Fax : <?php echo $satici_fax?>
            <br><br>
            E-Posta : <?php echo $satici_mail?>
            <br><br><br>

            4.TESLİM EDİLECEK KİŞİ BİLGİLERİ
            <br><br>
            Teslim edilecek kişi : *
            <br><br>
            Teslimat Adresi : *
            <br><br>
            Telefon : *
            <br><br>
            Fax : *
            <br><br>
            E-Posta : *

            <br><br><br>
            5.SİPARİŞ VEREN KİŞİ BİLGİLERİ
            <br><br>
            Sipariş veren kişi :*
            <br><br>
            Fatura Adresi :*
            <br><br>
            Telefon :*
            <br><br>
            Fax :*
            <br><br>
            E-Posta :*
            <br><br><br>

            6.SÖZLEŞME KONUSU ÜRÜN/ÜRÜNLER BİLGİLERİ
            <br><br>
            6.1. Malın /Ürün/Ürünlerin/ Hizmetin temel özelliklerini (türü, miktarı, marka/modeli, rengi, adedi) SATICI’ya ait internet sitesinde yayınlanmaktadır. Satıcı tarafından kampanya düzenlenmiş ise ilgili ürünün temel özelliklerini kampanya süresince inceleyebilirsiniz. Kampanya tarihine kadar geçerlidir.
            <br><br>
            6.2. Listelenen ve sitede ilan edilen fiyatlar satış fiyatıdır. İlan edilen fiyatlar ve vaatler güncelleme yapılana ve değiştirilene kadar geçerlidir. Süreli olarak ilan edilen fiyatlar ise belirtilen süre sonuna kadar geçerlidir.
            <br><br>
            6.3. Sözleşme konusu mal ya da hizmetin tüm vergiler dâhil satış fiyatı aşağıda gösterilmiştir.

            <br><br><br><br>


            Ürün Açıklaması xAdet Birim Fiyatı Ara Toplam
            <br><br><br>

            Kargo Tutarı (KDV Dahil) :*
            <br><br>
            Toplam (KDV Dahil) :*
            <br><br>
            Ödeme Şekli ve Planı :*
            <br><br>
            Sipariş Tarihi :*
            <br><br>
            Teslimat Tarihi :*
            <br><br>
            7.4. Ürün sevkiyat masrafı olan kargo ücreti ALICI tarafından ödenecektir.
            <br><br><br>

            7. FATURA BİLGİLERİ
            <br><br>
            Ad Soyad/Şirket Adı : *
            <br><br>
            Vergi Dairesi/VergiNo : /*
            <br><br>
            Fatura Adresi :*
            <br><br>
            Telefon :*
            <br><br>
            Fax :*
            <br><br>
            E-Posta :*
            <br><br>
            Fatura teslimi sipariş teslimatı sırasında fatura adresine sipariş ile birlikte teslim edilecektir.
            <br><br><br>

            7. GENEL HÜKÜMLER
            <br><br>
            7.1. ALICI, SATICI’ya ait internet sitesinde sözleşme konusu ürünün temel nitelikleri, satış fiyatı ve ödeme şekli ile teslimata ilişkin ön bilgileri okuyup, bilgi sahibi olduğunu, elektronik ortamda gerekli teyidi verdiğini kabul, beyan ve taahhüt eder. ALICI’nın; Ön Bilgilendirmeyi elektronik ortamda teyit etmesi, mesafeli satış sözleşmesinin kurulmasından evvel, SATICI tarafından ALICI’ ya verilmesi gereken adresi, siparişi verilen ürünlere ait temel özellikleri, ürünlerin vergiler dâhil fiyatını, ödeme ve teslimat bilgilerini de doğru ve eksiksiz olarak edindiğini kabul, beyan ve taahhüt eder.
            <br><br>
            7.2. Sözleşme konusu her bir ürün, 30 günlük yasal süreyi aşmamak kaydı ile ALICI’ nın yerleşim yeri uzaklığına bağlı olarak internet sitesindeki ön bilgiler kısmında belirtilen süre zarfında ALICI veya ALICI’nın gösterdiği adresteki kişi ve/veya kuruluşa teslim edilir. Bu süre içinde ürünün ALICI’ya teslim edilememesi durumunda, ALICI’nın sözleşmeyi feshetme hakkı saklıdır.
            <br><br>
            7.3. SATICI, Sözleşme konusu ürünü eksiksiz, siparişte belirtilen niteliklere uygun ve varsa garanti belgeleri, kullanım kılavuzları işin gereği olan bilgi ve belgeler ile teslim etmeyi, her türlü ayıptan arî olarak yasal mevzuat gereklerine göre sağlam, standartlara uygun bir şekilde işi doğruluk ve dürüstlük esasları dâhilinde ifa etmeyi, hizmet kalitesini koruyup yükseltmeyi, işin ifası sırasında gerekli dikkat ve özeni göstermeyi, ihtiyat ve öngörü ile hareket etmeyi kabul, beyan ve taahhüt eder.
            <br><br>
            7.4. SATICI, sözleşmeden doğan ifa yükümlülüğünün süresi dolmadan ALICI’yı bilgilendirmek ve açıkça onayını almak suretiyle eşit kalite ve fiyatta farklı bir ürün tedarik edebilir.
            <br><br>
            7.5. SATICI, sipariş konusu ürün veya hizmetin yerine getirilmesinin imkânsızlaşması halinde sözleşme konusu yükümlülüklerini yerine getiremezse, bu durumu, öğrendiği tarihten itibaren 3 gün içinde yazılı olarak tüketiciye bildireceğini, 14 günlük süre içinde toplam bedeli ALICI’ya iade edeceğini kabul, beyan ve taahhüt eder.
            <br><br>
            7.6. ALICI, Sözleşme konusu ürünün teslimatı için işbu Sözleşme’yi elektronik ortamda teyit edeceğini, herhangi bir nedenle sözleşme konusu ürün bedelinin ödenmemesi ve/veya banka kayıtlarında iptal edilmesi halinde, SATICI’nın sözleşme konusu ürünü teslim yükümlülüğünün sona ereceğini kabul, beyan ve taahhüt eder.
            <br><br>
            7.7. ALICI, Sözleşme konusu ürünün ALICI veya ALICI’nın gösterdiği adresteki kişi ve/veya kuruluşa tesliminden sonra ALICI’ya ait kredi kartının yetkisiz kişilerce haksız kullanılması sonucunda sözleşme konusu ürün bedelinin ilgili banka veya finans kuruluşu tarafından SATICI’ya ödenmemesi halinde, ALICI Sözleşme konusu ürünü 3 gün içerisinde nakliye gideri SATICI’ya ait olacak şekilde SATICI’ya iade edeceğini kabul, beyan ve taahhüt eder.
            <br><br>
            7.8. SATICI, tarafların iradesi dışında gelişen, önceden öngörülemeyen ve tarafların borçlarını yerine getirmesini engelleyici ve/veya geciktirici hallerin oluşması gibi mücbir sebepler halleri nedeni ile sözleşme konusu ürünü süresi içinde teslim edemez ise, durumu ALICI’ya bildireceğini kabul, beyan ve taahhüt eder. ALICI da siparişin iptal edilmesini, sözleşme konusu ürünün varsa emsali ile değiştirilmesini ve/veya teslimat süresinin engelleyici durumun ortadan kalkmasına kadar ertelenmesini SATICI’dan talep etme hakkını haizdir. ALICI tarafından siparişin iptal edilmesi halinde ALICI’nın nakit ile yaptığı ödemelerde, ürün tutarı 14 gün içinde kendisine nakden ve defaten ödenir. ALICI’nın kredi kartı ile yaptığı ödemelerde ise, ürün tutarı, siparişin ALICI tarafından iptal edilmesinden sonra 14 gün içerisinde ilgili bankaya iade edilir. ALICI, SATICI tarafından kredi kartına iade edilen tutarın banka tarafından ALICI hesabına yansıtılmasına ilişkin ortalama sürecin 2 ile 3 haftayı bulabileceğini, bu tutarın bankaya iadesinden sonra ALICI’nın hesaplarına yansıması halinin tamamen banka işlem süreci ile ilgili olduğundan, ALICI, olası gecikmeler için SATICI’yı sorumlu tutamayacağını kabul, beyan ve taahhüt eder.
            <br><br>
            7.9. SATICININ, ALICI tarafından siteye kayıt formunda belirtilen veya daha sonra kendisi tarafından güncellenen adresi, e-posta adresi, sabit ve mobil telefon hatları ve diğer iletişim bilgileri üzerinden mektup, e-posta, SMS, telefon görüşmesi ve diğer yollarla iletişim, pazarlama, bildirim ve diğer amaçlarla ALICI’ya ulaşma hakkı bulunmaktadır. ALICI, işbu sözleşmeyi kabul etmekle SATICI’nın kendisine yönelik yukarıda belirtilen iletişim faaliyetlerinde bulunabileceğini kabul ve beyan etmektedir.
            <br><br>
            7.10. ALICI, sözleşme konusu mal/hizmeti teslim almadan önce muayene edecek; ezik, kırık, ambalajı yırtılmış vb. hasarlı ve ayıplı mal/hizmeti kargo şirketinden teslim almayacaktır. Teslim alınan mal/hizmetin hasarsız ve sağlam olduğu kabul edilecektir. Teslimden sonra mal/hizmetin özenle korunması borcu, ALICI’ya aittir. Cayma hakkı kullanılacaksa mal/hizmet kullanılmamalıdır. Fatura iade edilmelidir.
            <br><br>
            7.11. ALICI ile sipariş esnasında kullanılan kredi kartı hamilinin aynı kişi olmaması veya ürünün ALICI’ya tesliminden evvel, siparişte kullanılan kredi kartına ilişkin güvenlik açığı tespit edilmesi halinde, SATICI, kredi kartı hamiline ilişkin kimlik ve iletişim bilgilerini, siparişte kullanılan kredi kartının bir önceki aya ait ekstresini yahut kart hamilinin bankasından kredi kartının kendisine ait olduğuna ilişkin yazıyı ibraz etmesini ALICI’dan talep edebilir. ALICI’nın talebe konu bilgi/belgeleri temin etmesine kadar geçecek sürede sipariş dondurulacak olup, mezkur taleplerin 24 saat içerisinde karşılanmaması halinde ise SATICI, siparişi iptal etme hakkını haizdir.
            <br><br>
            7.12. ALICI, SATICI’ya ait internet sitesine üye olurken verdiği kişisel ve diğer sair bilgilerin gerçeğe uygun olduğunu, SATICI’nın bu bilgilerin gerçeğe aykırılığı nedeniyle uğrayacağı tüm zararları, SATICI’nın ilk bildirimi üzerine derhal, nakden ve defaten tazmin edeceğini beyan ve taahhüt eder.
            <br><br>
            7.13. ALICI, SATICI’ya ait internet sitesini kullanırken yasal mevzuat hükümlerine riayet etmeyi ve bunları ihlal etmemeyi baştan kabul ve taahhüt eder. Aksi takdirde, doğacak tüm hukuki ve cezai yükümlülükler tamamen ve münhasıran ALICI’yı bağlayacaktır.
            <br><br>
            7.14. ALICI, SATICI’ya ait internet sitesini hiçbir şekilde kamu düzenini bozucu, genel ahlaka aykırı, başkalarını rahatsız ve taciz edici şekilde, yasalara aykırı bir amaç için, başkalarının maddi ve manevi haklarına tecavüz edecek şekilde kullanamaz. Ayrıca, üye başkalarının hizmetleri kullanmasını önleyici veya zorlaştırıcı faaliyet (spam, virus, truva atı, vb.) işlemlerde bulunamaz.
            <br><br>
            7.15. SATICI’ya ait internet sitesinin üzerinden, SATICI’nın kendi kontrolünde olmayan ve/veya başkaca üçüncü kişilerin sahip olduğu ve/veya işlettiği başka web sitelerine ve/veya başka içeriklere link verilebilir. Bu linkler ALICI’ya yönlenme kolaylığı sağlamak amacıyla konmuş olup herhangi bir web sitesini veya o siteyi işleten kişiyi desteklememekte ve Link verilen web sitesinin içerdiği bilgilere yönelik herhangi bir garanti niteliği taşımamaktadır.
            <br><br>
            7.16. İşbu sözleşme içerisinde sayılan maddelerden bir ya da birkaçını ihlal eden üye işbu ihlal nedeniyle cezai ve hukuki olarak şahsen sorumlu olup, SATICI’yı bu ihlallerin hukuki ve cezai sonuçlarından ari tutacaktır. Ayrıca; işbu ihlal nedeniyle, olayın hukuk alanına intikal ettirilmesi halinde, SATICI’nın üyeye karşı üyelik sözleşmesine uyulmamasından dolayı tazminat talebinde bulunma hakkı saklıdır.
            <br><br><br>

            8. CAYMA HAKKI
            <br><br>
            8.1. ALICI; mesafeli sözleşmenin mal satışına ilişkin olması durumunda, ürünün kendisine veya gösterdiği adresteki kişi/kuruluşa teslim tarihinden itibaren 14 (on dört) gün içerisinde, SATICI’ya bildirmek şartıyla hiçbir hukuki ve cezai sorumluluk üstlenmeksizin ve hiçbir gerekçe göstermeksizin malı reddederek sözleşmeden cayma hakkını kullanabilir. Hizmet sunumuna ilişkin mesafeli sözleşmelerde ise, bu süre sözleşmenin imzalandığı tarihten itibaren başlar. Cayma hakkı süresi sona ermeden önce, tüketicinin onayı ile hizmetin ifasına başlanan hizmet sözleşmelerinde cayma hakkı kullanılamaz. Cayma hakkının kullanımından kaynaklanan masraflar SATICI’ ya aittir. ALICI, iş bu sözleşmeyi kabul etmekle, cayma hakkı konusunda bilgilendirildiğini peşinen kabul eder.
            <br><br>
            8.2. Cayma hakkının kullanılması için 14 (ondört) günlük süre içinde SATICI’ ya iadeli taahhütlü posta, faks veya eposta ile yazılı bildirimde bulunulması ve ürünün işbu sözleşmede düzenlenen “Cayma Hakkı Kullanılamayacak Ürünler” hükümleri çerçevesinde kullanılmamış olması şarttır. Bu hakkın kullanılması halinde,
            <br><br>
            a) 3. kişiye veya ALICI’ ya teslim edilen ürünün faturası, (İade edilmek istenen ürünün faturası kurumsal ise, iade ederken kurumun düzenlemiş olduğu iade faturası ile birlikte gönderilmesi gerekmektedir. Faturası kurumlar adına düzenlenen sipariş iadeleri İADE FATURASI kesilmediği takdirde tamamlanamayacaktır.)
            <br><br>
            b) İade formu,
            <br><br>
            c) İade edilecek ürünlerin kutusu, ambalajı, varsa standart aksesuarları ile birlikte eksiksiz ve hasarsız olarak teslim edilmesi gerekmektedir.
            <br><br>
            d) SATICI, cayma bildiriminin kendisine ulaşmasından itibaren en geç 10 günlük süre içerisinde toplam bedeli ve ALICI’yı borç altına sokan belgeleri ALICI’ ya iade etmek ve 20 günlük süre içerisinde malı iade almakla yükümlüdür.
            <br><br>
            e) ALICI’ nın kusurundan kaynaklanan bir nedenle malın değerinde bir azalma olursa veya iade imkânsızlaşırsa ALICI kusuru oranında SATICI’ nın zararlarını tazmin etmekle yükümlüdür. Ancak cayma hakkı süresi içinde malın veya ürünün usulüne uygun kullanılması sebebiyle meydana gelen değişiklik ve bozulmalardan ALICI sorumlu değildir.
            <br><br>
            f) Cayma hakkının kullanılması nedeniyle SATICI tarafından düzenlenen kampanya limit tutarının altına düşülmesi halinde kampanya kapsamında faydalanılan indirim miktarı iptal edilir.
            <br><br><br>

            9.CAYMA HAKKI KULLANILAMAYACAK ÜRÜNLER
            <br><br>
            9.1. ALICI’nın isteği veya açıkça kişisel ihtiyaçları doğrultusunda hazırlanan ve geri gönderilmeye müsait olmayan, iç giyim alt parçaları, mayo ve bikini altları, makyaj malzemeleri, tek kullanımlık ürünler, çabuk bozulma tehlikesi olan veya son kullanma tarihi geçme ihtimali olan mallar, ALICI’ya teslim edilmesinin ardından ALICI tarafından ambalajı açıldığı takdirde iade edilmesi sağlık ve hijyen açısından uygun olmayan ürünler, teslim edildikten sonra başka ürünlerle karışan ve doğası gereği ayrıştırılması mümkün olmayan ürünler, Abonelik sözleşmesi kapsamında sağlananlar dışında, gazete ve dergi gibi süreli yayınlara ilişkin mallar, Elektronik ortamda anında ifa edilen hizmetler veya tüketiciye anında teslim edilen gayrimaddi mallar, ile ses veya görüntü kayıtlarının, kitap, dijital içerik, yazılım programlarının, veri kaydedebilme ve veri depolama cihazlarının, bilgisayar sarf malzemelerinin, ambalajının ALICI tarafından açılmış olması halinde iadesi Yönetmelik gereği mümkün değildir. Ayrıca Cayma hakkı süresi sona ermeden önce, tüketicinin onayı ile ifasına başlanan hizmetlere ilişkin cayma hakkının kullanılması da Yönetmelik gereği mümkün değildir.
            <br><br>
            9.2. Kozmetik ve kişisel bakım ürünleri, iç giyim ürünleri, mayo, bikini, kitap, kopyalanabilir yazılım ve programlar, DVD, VCD, CD ve kasetler ile kırtasiye sarf malzemeleri (toner, kartuş, şerit vb.) iade edilebilmesi için ambalajlarının açılmamış, denenmemiş, bozulmamış ve kullanılmamış olmaları gerekir.
            <br><br><br>

            10.TEMERRÜT HALİ VE HUKUKİ SONUÇLARI
            <br><br>
            ALICI, ödeme işlemlerini kredi kartı ile yaptığı durumda temerrüde düştüğü takdirde, kart sahibi banka ile arasındaki kredi kartı sözleşmesi çerçevesinde faiz ödeyeceğini ve bankaya karşı sorumlu olacağını kabul, beyan ve taahhüt eder. Bu durumda ilgili banka hukuki yollara başvurabilir; doğacak masrafları ve vekâlet ücretini ALICI’dan talep edebilir ve her koşulda ALICI’nın borcundan dolayı temerrüde düşmesi halinde, ALICI, borcun gecikmeli ifasından dolayı SATICI’nın uğradığı zarar ve ziyanını ödeyeceğini kabul, beyan ve taahhüt eder
            <br><br><br>

            11.YETKİLİ MAHKEME
            <br><br>
            İşbu sözleşmeden doğan uyuşmazlıklarda şikayet ve itirazlar, aşağıdaki kanunda belirtilen parasal sınırlar dâhilinde tüketicinin yerleşim yerinin bulunduğu veya tüketici işleminin yapıldığı yerdeki tüketici sorunları hakem heyetine veya tüketici mahkemesine yapılacaktır. Parasal sınıra ilişkin bilgiler aşağıdadır:
            <br><br>
            01/01/2017 tarihinden itibaren geçerli olmak üzere, 2017 yılı için tüketici hakem heyetlerine yapılacak başvurularda değeri:
            <br><br>
            a) 2.400 (iki bin dört yüz) Türk Lirasının altında bulunan uyuşmazlıklarda ilçe tüketici hakem heyetleri,
            <br><br>
            b) Büyükşehir statüsünde olan illerde 2.400 (iki bin dört yüz) Türk Lirası ile 3.610 (üç bin altı yüz on) Türk Lirası arasındaki uyuşmazlıklarda il tüketici hakem heyetleri,
            <br><br>
            c) Büyükşehir statüsünde olmayan illerin merkezlerinde 3.610 (üç bin altı yüz on) Türk Lirasının altında bulunan uyuşmazlıklarda il tüketici hakem heyetleri,
            <br><br>
            ç) Büyükşehir statüsünde olmayan illere bağlı ilçelerde 2.400 (iki bin dört yüz) Türk Lirası ile 3.610 (üç bin altı yüz on) Türk Lirası arasındaki uyuşmazlıklarda il tüketici hakem heyetleri görevli kılınmışlardır.
            <br><br>
            İşbu Sözleşme ticari amaçlarla yapılmaktadır.
            <br><br><br>

            12.YÜRÜRLÜK
            <br><br>
            ALICI, Site üzerinden verdiği siparişe ait ödemeyi gerçekleştirdiğinde işbu sözleşmenin tüm şartlarını kabul etmiş sayılır. SATICI, siparişin gerçekleşmesi öncesinde işbu sözleşmenin sitede ALICI tarafından okunup kabul edildiğine dair onay alacak şekilde gerekli yazılımsal düzenlemeleri yapmakla yükümlüdür.
            <br><br><br>

            SATICI: <?php echo $satici_name?>
            <br><br>
            ALICI: <?php echo $alici_name?>
            <br><br>
            TARİH: <?php echo date("Y-m-d H:i:s")?>
        </div>
    </div>
</div>

<script>
    $("#open-sozlesme").click(() => {
        $("#sozlesme-dis").fadeIn(200);
    });

    $("#close-sozlesme").click(() => {
        $("#sozlesme-dis").fadeOut(200);
    });
</script>