<?php

use Router\Router;

$sc = new \SessionController\SessionController();

$status = $sc->Get("PAYMENT_PAGE_PAY_ID_STATUS");
$sc->Set("PAYMENT_PAGE_PAY_ID_STATUS" , null);

if (!isset($status) || $status == null || $status == "")
    Router::Route("");

header("Refresh:4, /dashboard");
?>



<div class="w-full h-screen bg-white flex justify-center items-center mx-3 md:mx-0">
    <div class="w-full md:w-[400px] h-[300px] flex flex-col items-center">
        <div class="logo text-9xl text-blue-600 mt-3 mb-3"><i class="fa-solid fa-circle-check"></i></div>
        <div class="font-bold text-2xl mt-3 font-bold text-gray-900">
            Payment Success
        </div>

        <div class="font-bold text-sm mt-3 font-bold text-gray-900 text-center p-3">
            Your payment has been received successfully. You can safely close this page and return to the panel. But you will have to wait a few minutes :)
        </div>
    </div>
</div>