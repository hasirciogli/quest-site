<?php

return;

//return;
//$data = file_get_contents("/home/yokartkc/domains/hsrcpay.com/public_html/app/crons/x.txt");
//file_put_contents("/home/yokartkc/domains/hsrcpay.com/public_html/app/crons/x.txt", $data . "31 \n");


require "/home/yokartkc/domains/hsrcpay.com/public_html/vendor/autoload.php";
require "/home/yokartkc/domains/hsrcpay.com/public_html/app/FFunctions/FrameworkFunctions.php";
require "/home/yokartkc/domains/hsrcpay.com/public_html/app/Database/Database.php";
require "/home/yokartkc/domains/hsrcpay.com/public_html/app/Configs/Config.php";

use DATABASE\Database;
use \FrameworkFunctions\FrameworkFunctions;

/*$v = Database::sql("SELECT * FROM websites WHERE status='waiting'");
$x = $v->execute([]);
$result = $v->fetchAll(PDO::FETCH_ASSOC);

if ($v->rowCount() && $x){

    foreach ($result as $item) {
        $v     = Database::sql("UPDATE websites SET status=? WHERE id=?");
        $x     = $v->execute(["active", $item["id"]]);
        $result    = $v->fetch(PDO::FETCH_ASSOC);

        $owner_id       = $item["owner_id"];
        $status         = $item["status"];
        $domain         = $item["domain"];
        $callback_url   = $item["callback_url"];



        $v      = Database::sql("SELECT * FROM users WHERE id=?");
        $x      = $v->execute([$owner_id]);
        $result = $v->fetch(PDO::FETCH_ASSOC);

        if ($v->rowCount() && $x){
            \FrameworkFunctions\FrameworkFunctions::get()->SendMail($result["email"], "YOUR SITE CONFIRMD (" . $domain . ")","
            Your website has been activated collect moneys! <br>
            Domain: ". $domain . " <br> 
            Status: ". "active" . " <br>
            Callback: ". $callback_url . " <br>
        ", null);
        }
    }
}
*/



class WebsiteOwnerCheckerClass{
    public function _prun(){
        $websites = $this->getWebsites();

        foreach($websites as $site) {

            $mail_owner = $this->getWebsiteOwner($site["owner_id"]);

            if ($site["owner_check_count"] >= 10){
                if ($this->deleteWebsite($site["id"])){
                    $this->sendDeletedEmail($mail_owner["email"], $site["domain"]);
                }
            }
            else{

                $this->garterWOC($site["id"], $site["owner_check_count"] + 1);
                //$this->setFile("owner email: " . $this->getWebsiteOwner($site["owner_id"])["email"]);

                if ($this->checkOwner($site["domain"], $site["id"], $mail_owner["email"])){

                    $this->setStatusToWebsite($site["id"],"active");

                    $this->sendActivatedEmail($mail_owner["email"], $site["domain"]);
                }
            }
        }
    }

    private function getWebsites(){
        $v = Database::sql("SELECT * FROM websites WHERE status='owner_check'");
        $x = $v->execute([]);
        return $v->fetchAll(PDO::FETCH_ASSOC);
    }

    private function setFile($data){
        file_put_contents("/home/yokartkc/domains/hsrcpay.com/public_html/app/crons/x.txt", $data);
    }


    private function checkOwner($domain, $domain_id,$email){
        $curlSession = curl_init();
        curl_setopt($curlSession, CURLOPT_URL, "http://". $domain . "/hsrcpay-ownercheck.txt");
        curl_setopt($curlSession, CURLOPT_RETURNTRANSFER, true);

        $user_email = curl_exec($curlSession);
        curl_close($curlSession);

        if ($user_email == $email){
            $this->updateSiteSSL($domain_id,"no");
            return true;
        }else{
            $curlSession = curl_init();
            curl_setopt($curlSession, CURLOPT_URL, "https://". $domain . "/hsrcpay-ownercheck.txt");
            curl_setopt($curlSession, CURLOPT_RETURNTRANSFER, true);

            $user_email = curl_exec($curlSession);
            curl_close($curlSession);

            if ($user_email == $email){
                $this->updateSiteSSL($domain_id,"yes");
                return true;
            }
        }

        return false;
    }

    private function garterWOC($website_id, $integer){
        $v = Database::sql("UPDATE websites SET owner_check_count=? WHERE id=?");
        $x = $v->execute([$integer, $website_id]);
        return $x;
    }

    private function updateSiteSSL($website_id, $ssl){
        $v = Database::sql("UPDATE websites SET site_ssl=? WHERE id=?");
        $x = $v->execute([$ssl, $website_id]);
        return $x;
    }

    private function deleteWebsite($website_id){
        $v = Database::sql("DELETE FROM websites WHERE id=?");
        $x = $v->execute([$website_id]);
        return $x;
    }

    private function setStatusToWebsite($website_id, $status){
        $v = Database::sql("UPDATE websites SET status=? WHERE id=?");
        $x = $v->execute([$status, $website_id]);
        return $x;
    }

    private function getWebsiteOwner($owner_id){
        $v = Database::sql("SELECT * FROM users WHERE id=?");
        $x = $v->execute([$owner_id]);
        return $v->fetch(PDO::FETCH_ASSOC);
    }
                       
    private function sendDeletedEmail($to, $domain){
        FrameworkFunctions::get()->SendMail(
            $to,
            "Your website has ben deleted! (" . $domain . ")",
            "Your website deleted because owner check failed!",
            null
        );
    }

    private function sendActivatedEmail($to, $domain){
        FrameworkFunctions::get()->SendMail(
            $to,
            "Your website has been activated! (" . $domain . ")",
            $domain . " active right now!",
            null
        );
    }
}



$wocc = new WebsiteOwnerCheckerClass();

$wocc->_prun();


?>