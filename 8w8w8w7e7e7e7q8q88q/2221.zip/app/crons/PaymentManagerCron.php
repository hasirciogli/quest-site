<?php

require "/home/yokartkc/domains/hsrcpay.com/public_html/vendor/autoload.php";
require "/home/yokartkc/domains/hsrcpay.com/public_html/app/FFunctions/FrameworkFunctions.php";
require "/home/yokartkc/domains/hsrcpay.com/public_html/app/Database/Database.php";
require "/home/yokartkc/domains/hsrcpay.com/public_html/app/Configs/Config.php";


use DATABASE\FFDatabase;

date_default_timezone_set('Europe/Istanbul');

//header("Content-Type: application/json");

class PaymentManagerCron
{
    public function listPayments()
    {
        $payments = $this->getReqPayments();
        $output = "";
        if ($payments && $payments != "no-record") {
            foreach ($payments as $item) {

                $currently_istanbul_date_time = strtotime(date("Y-m-d H:i:s.u"));

                $payment_created_date = strtotime($item["created_at"]);

                $day_piece = ($currently_istanbul_date_time - $payment_created_date) / 86400;

                $cuted_day_price = number_format($day_piece, 2, '.', '');

                if ($cuted_day_price >= 3.0) {
                    $ffdb = FFDatabase::cfun();
                    $ffdb->update("payment_requests", [["balance_status", "valid"]])->where("id", $item["id"])->run();
                    $ffdb = null;

                    $ffdb = FFDatabase::cfun();
                    $owner_user = $ffdb->select("users")->where("id", $item["owner_user_id"])->run()->get();
                    $ffdb = null;

                    $cbalance = $owner_user["confirmed_balance"] + $item["price"];
                    $ucbalance = $owner_user["unconfirmed_balance"] - $item["price"];

                    $ffdb = FFDatabase::cfun();
                    $result = $ffdb->update("users",
                        [
                            [
                                "confirmed_balance",
                                ($cbalance),
                            ],
                            [
                                "unconfirmed_balance",
                                ($ucbalance),
                            ]
                        ]
                    )->where("id", $item["owner_user_id"])->run();
                    $ffdb = null;

                    if ($result->x) {

                    }
                }

                echo $item["created_at"] . " | fark: " . $cuted_day_price . "<br>";
            }
        }
    }

    public function getReqPayments()
    {
        return FFDatabase::cfun()->select("payment_requests")->where("status", "confirmed")->where("payment_type", "api")->where("balance_status", "waiting")->run()->getAll();
    }

    private function updateRequiredPaymets()
    {

    }
}

$pmc = new PaymentManagerCron();

$pmc->listPayments();


?>