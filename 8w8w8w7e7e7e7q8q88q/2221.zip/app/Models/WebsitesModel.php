<?php

namespace WebsitesModel;

use AuthController\AuthController;
use DATABASE\Database;
use SessionController\SessionController;

class WebsitesModel extends \DATABASE\Database
{
    protected function _getWebsiteFromDomainName($domain){
        $result = parent::sql("SELECT * FROM websites WHERE BINARY domain=?");
        $x = $result->execute([$domain]);
        $x2 = $result->fetch(\PDO::FETCH_ASSOC);

        if ($result->rowCount() > 0 && $x){
            return $x2;
        }
        else{
            if ($x)
                return "no-record";
            else
                return false;
        }
    }
    protected function _getUserWebsites($id, $get_type = null){
        $result = parent::sql("SELECT * FROM websites WHERE BINARY owner_id=?" . ($get_type == "desc" ? " ORDER BY id DESC" : ""));
        $x = $result->execute([$id]);
        $x2 = $result->fetchAll(\PDO::FETCH_ASSOC);

        if ($result->rowCount() > 0 && $x){
            $result = null;
            return $x2;
        }
        else{
            if ($x)
                return "no-record";
            else
                return false;
        }
    }

    protected function _addUserWebsites($domain, $callback, $id){

        $websites_get_result = $this->_getUserWebsites($id);

        $smc = new SessionController();

        if($websites_get_result == false)
        {
            $smc->Set("SESSION_WEBSITES_SHOW_ERROR"    , true);
            $smc->Set("SESSION_WEBSITES_ERROR"          , "Internal server error");

            return false;

        }

        if ($websites_get_result != "no-record")
        {
            if(count($websites_get_result) >= AuthController::getUserData()[1]["website_limit"]){
                $smc->Set("SESSION_WEBSITES_SHOW_ERROR"    , true);
                $smc->Set("SESSION_WEBSITES_ERROR"          , "Website Limit 4 you have 4");

                return false;
            }

            if($websites_get_result != null && count($websites_get_result) > 0){
                foreach ($websites_get_result as $item){
                    if ($domain == $item["domain"]){
                        $smc->Set("SESSION_WEBSITES_SHOW_ERROR"    , true);
                        $smc->Set("SESSION_WEBSITES_ERROR"          , "Domain allready registered");

                        return false;
                    }
                }
            }
        }

        $gwfdn = $this->_getWebsiteFromDomainName($domain);

        if($gwfdn != false && $gwfdn != "no-record"){
            $smc->Set("SESSION_WEBSITES_SHOW_ERROR"    , true);
            $smc->Set("SESSION_WEBSITES_ERROR"          , "Domain allready registered another user");
            return false;
        }
        else{
            if($gwfdn != "no-record")
            {
                $smc->Set("SESSION_WEBSITES_SHOW_ERROR"    , true);
                $smc->Set("SESSION_WEBSITES_ERROR"          , "Internal gwfdn ERROR try again later");
                return false;
            }
        }

        $result = parent::sql("INSERT INTO websites (domain, callback_url, owner_id, status) VALUES (?, ?, ?, ?)");
        $x = $result->execute([$domain, $callback, $id, "owner_check"]);
        $x2 = $result->fetch(\PDO::FETCH_ASSOC);

        if ($result->rowCount() && $x){
            $result = null;
            return true;
        }
        else{
            return null;
        }
    }

    protected function _removeUserWebsites($domain, $id){
        $cnt = false;
        foreach ($this->_getUserWebsites($id) as $item){
            if ($domain == $item["domain"] && $item["owner_id"] == $id && $item["status"] != "blocked"){
                $cnt = true;
            }
        }

        if ($cnt) {
            $result = parent::sql("DELETE FROM websites WHERE BINARY domain=?");
            $x = $result->execute([$domain]);
            $x2 = $result->fetch(\PDO::FETCH_ASSOC);

            if ($result->rowCount() && $x){
                $result = null;
                return true;
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }

    }

    protected function _updateUserWebsites($old_domain, $new_domain, $new_callback, $id){
        $smc = new SessionController();
        $cnt = false;
        //$req_count = 0;

        $scanned_site_data = null;


        foreach ($this->_getUserWebsites($id) as $item){
            if ($old_domain == $item["domain"] && $item["owner_id"] == $id){
                if($item["status"] != "blocked" && $item["status"] != "owner_check")
                    $cnt = true;
                $scanned_site_data = $item;
                break;
            }
        }

        if ($cnt) {

            $gwfdn = $this->_getWebsiteFromDomainName($new_domain);

            if($gwfdn != false && $gwfdn != "no-record" && $gwfdn["owner_id"] != $id){
                $smc->Set("SESSION_WEBSITES_SHOW_ERROR"    , true);
                $smc->Set("SESSION_WEBSITES_ERROR"          , "Domain update failed. bcs allready registered another user");
                return false;
            }
            else{
                if($gwfdn != "no-record" && $gwfdn["owner_id"] != $id)
                {
                    $smc->Set("SESSION_WEBSITES_SHOW_ERROR"    , true);
                    $smc->Set("SESSION_WEBSITES_ERROR"          , "Internal gwfdn ERROR try again later");
                    return false;
                }
            }

            $result = parent::sql("UPDATE websites SET domain=?, callback_url=?, status=?, review_request_count=? WHERE BINARY domain=?");
            $x = $result->execute([$new_domain, $new_callback, "owner_check", 1, $old_domain]);
            $x2 = $result->fetch(\PDO::FETCH_ASSOC);

            if ($result->rowCount() && $x){
                $smc->Set("SESSION_WEBSITES_SHOW_ERROR"     , true);
                $smc->Set("SESSION_WEBSITES_ERROR"          , "UPDATE SUCCESS!");
                $result = null;
                return true;
            }
            else{
                $smc->Set("SESSION_WEBSITES_SHOW_ERROR"     , true);
                $smc->Set("SESSION_WEBSITES_ERROR"          , "error 1!");
                return false;
            }
        }
        else{
            if($scanned_site_data && $scanned_site_data["status"] == "owner_check" || $scanned_site_data["status"] == "blocked") {
                $smc->Set("SESSION_WEBSITES_SHOW_ERROR"     , true);
                $smc->Set("SESSION_WEBSITES_ERROR"          , "You cannot edit domains in Owner Check or Blocked!");
                return false;
            }

            $smc->Set("SESSION_WEBSITES_SHOW_ERROR"     , true);
            $smc->Set("SESSION_WEBSITES_ERROR"          , "error 2!");
            return false;
        }

    }

    protected function _requestReviewUserWebsite($domain, $id){
        $cnt = false;
        $oldVal = null;
        $req_count = 0;


        foreach ($this->_getUserWebsites($id) as $item){
            if ($domain == $item["domain"] && $item["owner_id"] == $id){
                $oldVal = $item["status"];
                $cnt = true;
                $req_count = $item["review_request_count"];
                $req_count++;;
            }
        }

        if ($cnt) {
            if($oldVal != "refused")
                return false;

            $result = parent::sql("UPDATE websites SET status=?, review_request_count=? WHERE domain=?");
            $x = $result->execute(["waiting", ($req_count++), $domain]);
            $x2 = $result->fetch(\PDO::FETCH_ASSOC);

            if ($result->rowCount() && $x){
                $result = null;
                return true;
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }

    }
}