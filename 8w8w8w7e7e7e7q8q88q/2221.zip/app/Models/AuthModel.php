<?php

namespace AuthModel;
use DATABASE\Database;

class AuthModel extends Database
{

}