<?php

namespace RestApiModel;

use DATABASE\Database;
use DATABASE\FFDatabase;
use DataLogger\DataLogger;
use DataLogger\DATALOGGER_LOG_TYPE;
use FrameworkFunctions\FrameworkFunctions;
use GatesController\GatesController;
use PaymentRequsetsController\PaymentRequsetsController;
USE PDO;
use ResponseBankController\ResponseBankController;
use Router\Router;

class RestApiModel extends \DATABASE\Database
{
    static function getDomainFromUrl($url)
    {
        $pieces = parse_url($url);
        $domain = isset($pieces['host']) ? $pieces['host'] : '';
        if (preg_match('/(?P<domain>[a-z0-3][a-z0-3\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)) {
            return $regs['domain'];
        }
        return false;
    }


    static function sendParamDie($error, array $paramters, $error_desc, $class){
        die(json_encode([
            "action" => false,
            "data"=> [
                "error" => $error,
                "error-description" => $error_desc,
                "class" => $class,
                "required-parameters" => $paramters,
                "your-ip-adress-recorded" => $_SERVER["REMOTE_ADDR"],
                "ip-address-info" => "Dont worry. This is our security process. Just trust us :) ",
            ]
        ],JSON_UNESCAPED_UNICODE));
    }
    static function sendErrDie($error, $error_desc, $class){
        die(json_encode([
            "action" => false,
            "data"=> [
                "error" => $error,
                "error-description" => $error_desc,
                "class" => $class,
                "your-ip-adress-recorded" => $_SERVER["REMOTE_ADDR"],
                "ip-address-info" => "Dont worry. This is our security process. Just trust us :) ",
            ]
        ],JSON_UNESCAPED_UNICODE));
    }
    static function sendCreateErr(){
        die(json_encode([
            "action" => false,
            "data"=> [
                "error" => "payment-create-error",
                "error-description" => "Playment create failed please try again",
                "class" => $_SERVER["REQUEST_URI"],
                "your-ip-adress-recorded" => $_SERVER["REMOTE_ADDR"],
                "ip-address-info" => "Dont worry. This is our security process. Just trust us :) ",
            ]
        ],JSON_UNESCAPED_UNICODE));
    }
    static function checkApiKeys(){
        $api_key    = FrameworkFunctions::get()->getCustomHeader("api-key");
        $api_secret = FrameworkFunctions::get()->getCustomHeader("api-secret");

        if (!$api_key || !$api_secret)
            return false;

        $v = parent::sql("SELECT * FROM users WHERE api_key=? AND api_secret=?");
        $x = $v->execute([$api_key, $api_secret]);
        $user = $v->fetch(PDO::FETCH_ASSOC);

        if ($v->rowCount() > 0 && $x){
            return $user;
        }
        return false;
    }
    static function checkPostParams(array $params){
        foreach($params as $item){
            if(!isset($_POST[$item]) || $_POST[$item] == null || $_POST[$item] == ""){
                return false;
                break;
            }
        }
        return true;
    }
    static function checkPostParam($param, $check_var_type = null){
        if(!isset($_POST[$param]) || $_POST[$param] == null || $_POST[$param] == "")
            return false;

        return true;
    }
    static function checkGetParam($param, $check_var_type = null){
        if(!isset($_GET[$param]) || $_GET[$param] == null || $_GET[$param] == "")
            return false;

        return true;
    }
    static function checkHost($param_domain){
        $param_domain_addr  = gethostbyname($param_domain);
        $request_addr       = $_SERVER["REMOTE_ADDR"];

        if($request_addr != $param_domain_addr){
            RestApiModel::sendErrDie("invalid-host", "Please send any requst to your confirmed or active website('s)", $_SERVER["REQUEST_URI"]);
            return false;
        }

        $v = Database::sql("SELECT * FROM websites WHERE domain=?");
        $x = $v->execute([$param_domain]);
        $result = $v->fetch(PDO::FETCH_ASSOC);

        if ($v->rowCount() > 0 && $x){
            return $result;
        }
        else{
            RestApiModel::sendErrDie("website-not-found", "Website not registered our server's", $_SERVER["REQUEST_URI"]);
            return false;
        }
    }
    static function FinishPayWithError($err){
        Router::Route("");
        die();
        //echo "ERROR -> " . $err;
    }











    public static function CreateNewPaymet($payment_owner_user){

        function send_param_err(){
            RestApiModel::sendParamDie("invalid-parameters", [
                "domain" => "xx.xxxxxxx.com.tr or xxxxx.com",
                "currency_unit" => ['USD', 'EURO', 'TL', 'RUB', 'GBP', 'HPM'],
                "price" => "0.00",
                "ip_address" => "customer-ipaddress or site-ipaddress",
            ], "", $_SERVER["REQUEST_URI"]);
            return true;
        }

        $request_domain             = RestApiModel::checkPostParam("domain")                ? $_POST["domain"]          :       send_param_err();

        $host_check_result          = RestApiModel::checkHost($request_domain);

        $request_currency_unit      = RestApiModel::checkPostParam("currency_unit")         ? $_POST["currency_unit"]   :       send_param_err();
        $request_price              = RestApiModel::checkPostParam("price")                 ? $_POST["price"]           :       send_param_err();
        $request_ip_address         = RestApiModel::checkPostParam("ip_address")            ? $_POST["ip_address"]      :       send_param_err();

        $db = Database::dbs();
        $v = $db->prepare("INSERT INTO payment_requests (domain, owner_user_id, price, currency_unit, ip_address, api_key, api_secret) VALUES (?, ?, ?, ?, ?,?, ?)");
        $x = $v->execute([$host_check_result["domain"], $host_check_result["owner_id"], $request_price, $request_currency_unit, $request_ip_address, $payment_owner_user["api_key"], $payment_owner_user["api_secret"]]);

        if ($v->rowCount() && $x){

            $temp_result = DataLogger::cfun()->logData(DATALOGGER_LOG_TYPE::PAYMENT_REQUESTS_CREATE_LOG, "RestApiModel.php on public static function CreateNewPaymet(payment_owner_user)", "New payment created at " . date("Y-m-d H-i-s"));
            $temp_result = null;

            die(json_encode([
                "action" => true,
                "data" => [
                    "hash" => hash("sha256", base64_encode(FrameworkFunctions::get()->getCustomHeader("api-key") . FrameworkFunctions::get()->getCustomHeader("api-secret"))),
                    "route_here" => configs_host_ssl . "://" . configs_host_domain . "/pay?p_id=" . $db->lastInsertId(),
                ]
            ],JSON_UNESCAPED_UNICODE));
        }
        else{
            RestApiModel::sendCreateErr();
        }

    }

    public static function Pay(){
        header("Content-type: text/html");

        $ccname         = RestApiModel::checkPostParam("cc_name")       ? $_POST["cc_name"]     : RestApiModel::FinishPayWithError("missing name");
        $ccnumber       = RestApiModel::checkPostParam("cc_number")     ? $_POST["cc_number"]   : RestApiModel::FinishPayWithError("missing number");
        $ccmonth        = RestApiModel::checkPostParam("cc_month")      ? $_POST["cc_month"]    : RestApiModel::FinishPayWithError("missing month");
        $ccyear         = RestApiModel::checkPostParam("cc_year")       ? $_POST["cc_year"]     : RestApiModel::FinishPayWithError("missing year");
        $cccvv          = RestApiModel::checkPostParam("cc_cvv")        ? $_POST["cc_cvv"]      : RestApiModel::FinishPayWithError("missing cvv");


        $sc = new \SessionController\SessionController();

        $p_id = $sc->Get("PAYMENT_PAGE_PAY_ID");
        if ($p_id == null || $p_id == "")
        {
            Router::Route("");
            return false;
        }

        $tmp_payment = PaymentRequsetsController::get()->GetPaymentOfId($p_id);

        //$gInstance = GatesController::createClassInstance();
        //$active_bank_id = $gInstance->getGate($gInstance->getDefaultPaymentGateId());

        switch ($tmp_payment["bank_id"]){
            case "2":
                \FinansbankPayment::CreateInstance()->create_pay(configs_payment_backtr . $p_id, $tmp_payment["price"], $tmp_payment["currency_unit"], $ccname, $ccnumber, $ccyear, $ccmonth, $cccvv);
                break;
            case "3":
                \VAKIFBankPayment::CreateInstance()->create_pay(configs_payment_backtr . $p_id, $tmp_payment["price"], $tmp_payment["currency_unit"], $ccname, $ccnumber, $ccyear, $ccmonth, $cccvv);
                break;
            case "4":
                \INGBankPayment::CreateInstance()->create_pay(configs_payment_backtr . $p_id, $tmp_payment["price"], $tmp_payment["currency_unit"], $ccname, $ccnumber, $ccyear, $ccmonth, $cccvv);
                break;
            case "5":
                \SEKERBankPayment::CreateInstance()->create_pay(configs_payment_backtr . $p_id, $tmp_payment["price"], $tmp_payment["currency_unit"], $ccname, $ccnumber, $ccyear, $ccmonth, $cccvv);
                break;
            case "6":
                \KUVEYTTURKPayment::CreateInstance()->create_pay(configs_payment_backtr . $p_id, $tmp_payment["price"], $tmp_payment["currency_unit"], $ccname, $ccnumber, $ccyear, $ccmonth, $cccvv);
                break;
            case "1":
                \DENIZBankPayment::CreateInstance()->create_pay(configs_payment_backtr . $p_id, $tmp_payment["price"], $tmp_payment["currency_unit"], $ccname, $ccnumber, $ccyear, $ccmonth, $cccvv);
                break;
            default:
                $hpg = "Hatalı para geçidi veya seçilen para geçidi aktif değil/eklenmemiş";
                FFDatabase::cfun()->update("payment_requests", [["status","cancelled"], ["response_data", $hpg]])->where("id",$tmp_payment["id"])->run();
                header("Refresh: 1, /dashboard");
                die($hpg);
                break;
        }

        $ffdb = FFDatabase::cfun();
        $db_payment_request = $ffdb->select("payment_requests")->where("id", $p_id)->run()->get();
        $ffdb = null;


        //        configs_payment_backtr . $p_id

        $ffdb = FFDatabase::cfun();
        $update_result = $ffdb->update("payment_requests", [["bank_payment_id", configs_payment_backtr . $p_id]])->where("id", $p_id)->run()->get();
        $ffdb = null;

        $ffdb = FFDatabase::cfun();
        $db_payment_user = $ffdb->select("users")->where("id", $db_payment_request["owner_user_id"])->run()->get();
        $ffdb = null;



        // TODO: There is a beta scene ( Just my stupid trys before correct code :d )

        return;
        $ffdb = FFDatabase::cfun();
        $result = $ffdb->update("payment_requests", [["status","confirmed"]])->where("id", $p_id)->run();
        $ffdb = null;



        $ffdb = FFDatabase::cfun();
        $result = $ffdb->update("users",
            [
                [
                    "unconfirmed_balance",
                    ($db_payment_user["unconfirmed_balance"] + $db_payment_request["price"])
                ]
            ]
        )->where("id", $db_payment_user["id"])->run();

        $sc->Set("PAYMENT_PAGE_PAY_ID_STATUS", "success");
        Router::Route("success");
    }

    public static function GetPaymentInfo(){

    }
}