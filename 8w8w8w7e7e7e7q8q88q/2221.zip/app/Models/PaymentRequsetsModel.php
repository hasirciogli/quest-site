<?php

namespace PaymentRequsetsModel;
use AuthController\AuthController;
use \DATABASE\Database;
use DATABASE\FFDatabase;

class PaymentRequsetsModel extends Database
{
    protected function _getUserOfPayment($id){
        return FFDatabase::cfun()->select("users")->where("id",  $id)->run()->get();
    }

    protected function _getPaymentOfId($id){
        return FFDatabase::cfun()->select("payment_requests")->where("id",  $id)->run()->get();
    }

    protected function _getPaymentFromDate($created_date){
        $res = FFDatabase::cfun()->select("payment_requests")->where("created_at_odate",  $created_date)->where("status", "confirmed")->run()->getAll();

        if (!$res)
            return null;
        elseif ($res == "no-record")
            return null;
        else
            return $res;
    }

    protected function _getPaymentPriceFromDate($created_date){
        $res = $this->_getPaymentFromDate($created_date);

        if (!$res)
            return 0.00;
        else{
            $price = 0.00;

            foreach ($res as $row) {
                $price += $row["price"];
            }

            return $price;
        }
    }

    protected function _getPaymentRequests(){
        $v = $this::sql("SELECT * FROM payment_requests");

        $v->execute([AuthController::getUserID()]);

        $data = $v->fetchAll(\PDO::FETCH_ASSOC);

        $v = null;

        return $data;
    }

    protected function _getLast10PaymentRequests(){

        $res1 = FFDatabase::cfun()->select("payment_requests")->orderby("id")->DESC()->limit("100")->run()->getAll();

        if($res1 == "no-record")
            return null;
        else if (!$res1)
            return null;
        else
            return $res1;


        $pagination = isset($_GET["list_page"]) ? $_GET["list_page"] : false;

        if ($pagination && $pagination != "1")
        {
            $all_reqst = FFDatabase::cfun()->select("payment_requests")->run()->getAll();

            $input = array("red", "green", "blue", "yellow");
            array_splice($input, 1, count($input), "orange");
            var_dump($input);

            if($pagination * 10 <= count($all_reqst)){
                array_splice($all_reqst,($pagination * 10 - 10), count($all_reqst) - ($pagination * 10 - 10));
                return $all_reqst;
            }
        }
        else{
            $v = $this::sql("SELECT * FROM payment_requests ORDER BY id DESC LIMIT 4");

            $v->execute();

            $data = $v->fetchAll(\PDO::FETCH_ASSOC);

            $v = null;

            return $data;
        }

    }

    protected function _getUserPaymentRequests(){
        $v = $this::sql("SELECT * FROM payment_requests WHERE owner_user_id=?");

        $v->execute([AuthController::getUserID()]);

        $data = $v->fetchAll(\PDO::FETCH_ASSOC);

        $v = null;

        return $data;
    }

    protected function _getUserLast10PaymentRequests(){
        $v = $this::sql("SELECT * FROM payment_requests WHERE owner_user_id=? ORDER BY id DESC LIMIT 4");

        $v->execute([AuthController::getUserID()]);

        $data = $v->fetchAll(\PDO::FETCH_ASSOC);

        $v = null;

        return $data;
    }


    protected function _getTodayCash(){
        $result = FFDatabase::cfun()->select("payment_requests")->where("created_at_odate", date("Y-m-d"))->where("status", "confirmed")->where("is_silent","0")->run()->getAll();
        $result2 = FFDatabase::cfun()->select("payment_requests")->where("created_at_odate", date("Y-m-d", strtotime('-1 day',strtotime(date("Y-m-d")))))->where("status", "confirmed")->where("is_silent","0")->run()->getAll();


        $tcash = 0.00;
        $tcash2 = 0.00;

        if (!$result) $tcash = 0.00;
        else if ($result == null) $tcash = 0.00;
        else if ($result == "") $tcash = 0.00;
        else if ($result == "no-record") $tcash = 0.00;
        else{
            foreach ($result as $item) {
                $tcash += $item["price"];
            }
        }


        if (!$result2) $tcash2 = 0.00;
        else if ($result2 == null) $tcash2 = 0.00;
        else if ($result2 == "") $tcash2 = 0.00;
        else if ($result2 == "no-record") $tcash2 = 0.00;
        else{
            foreach ($result2 as $item) {
                $tcash2 += $item["price"];
            }
        }


        if ($tcash != 0 && $tcash2 != 0)
            $tcash2 = (($tcash - $tcash2) / $tcash2) * 100;
        else
            $tcash2 = 100.00;

        return [number_format($tcash, 2, ".") , number_format($tcash2, 2, ".")];
    }

    protected function _getDenizbankTodayCash($formatted = null){
        $result = FFDatabase::cfun()->select("payment_requests")->where("created_at_odate", date("Y-m-d"))->where("status", "confirmed")->where("is_silent","0")->where("bank_id", 3)->run()->getAll();


        $tcash = 0.00;

        if (!$result) $tcash = 0.00;
        else if ($result == null) $tcash = 0.00;
        else if ($result == "") $tcash = 0.00;
        else if ($result == "no-record") $tcash = 0.00;
        else{
            foreach ($result as $item) {
                $tcash += $item["price"];
            }
        }


        if (isset($formatted) && $formatted == true){
            return $tcash = number_format($tcash, "2", ".", ",");
        }
        else{
            return $tcash;
        }
    }

    protected function _getFinansbankTodayCash($formatted = null){
        $result = FFDatabase::cfun()->select("payment_requests")->where("created_at_odate", date("Y-m-d"))->where("status", "confirmed")->where("is_silent","0")->where("bank_id", 5)->run()->getAll();


        $tcash = 0.00;

        if (!$result) $tcash = 0.00;
        else if ($result == null) $tcash = 0.00;
        else if ($result == "") $tcash = 0.00;
        else if ($result == "no-record") $tcash = 0.00;
        else{
            foreach ($result as $item) {
                $tcash += $item["price"];
            }
        }


        if (isset($formatted) && $formatted == true){
            return $tcash = number_format($tcash, "2", ".", ",");
        }
        else{
            return $tcash;
        }
    }

    protected function _getIngbankTodayCash($formatted = null){
        $bank_id = "4";
        $result = FFDatabase::cfun()->select("payment_requests")->where("created_at_odate", date("Y-m-d"))->where("status", "confirmed")->where("is_silent","0")->where("bank_id", $bank_id)->run()->getAll();


        $tcash = 0.00;

        if (!$result) $tcash = 0.00;
        else if ($result == null) $tcash = 0.00;
        else if ($result == "") $tcash = 0.00;
        else if ($result == "no-record") $tcash = 0.00;
        else{
            foreach ($result as $item) {
                $tcash += $item["price"];
            }
        }


        if (isset($formatted) && $formatted == true){
            return $tcash = number_format($tcash, "2", ".", ",");
        }
        else{
            return $tcash;
        }
    }

    protected function _getSekerbankTodayCash($formatted = null){
        $bank_id = "4";
        $result = FFDatabase::cfun()->select("payment_requests")->where("created_at_odate", date("Y-m-d"))->where("status", "confirmed")->where("is_silent","0")->where("bank_id", $bank_id)->run()->getAll();


        $tcash = 0.00;

        if (!$result) $tcash = 0.00;
        else if ($result == null) $tcash = 0.00;
        else if ($result == "") $tcash = 0.00;
        else if ($result == "no-record") $tcash = 0.00;
        else{
            foreach ($result as $item) {
                $tcash += $item["price"];
            }
        }


        if (isset($formatted) && $formatted == true){
            return $tcash = number_format($tcash, "2", ".", ",");
        }
        else{
            return $tcash;
        }
    }

    protected function _getVakifbankTodayCash($formatted = null){
        $bank_id = "3";
        $result = FFDatabase::cfun()->select("payment_requests")->where("created_at_odate", date("Y-m-d"))->where("status", "confirmed")->where("is_silent","0")->where("bank_id", $bank_id)->run()->getAll();


        $tcash = 0.00;

        if (!$result) $tcash = 0.00;
        else if ($result == null) $tcash = 0.00;
        else if ($result == "") $tcash = 0.00;
        else if ($result == "no-record") $tcash = 0.00;
        else{
            foreach ($result as $item) {
                $tcash += $item["price"];
            }
        }


        if (isset($formatted) && $formatted == true){
            return $tcash = number_format($tcash, "2", ".", ",");
        }
        else{
            return $tcash;
        }
    }

    protected function _getFailedPayments(){
        $result = FFDatabase::cfun()->select("payment_requests")->where("status", "refused")->where("is_silent","0")->run()->getAll();

        $tcash = "0.00";

        if (!$result) $tcash = 0.00;
        else if ($result == null) $tcash = 0.00;
        else if ($result == "") $tcash = 0.00;
        else if ($result == "no-record") $tcash = 0.00;
        else{
            foreach ($result as $item) {
                $tcash += $item["price"];
            }
        }

        return number_format($tcash, 2, ".");
    }

    protected function _getCompletedPayments(){
        $result = FFDatabase::cfun()->select("payment_requests")->where("status", "confirmed")->where("is_silent","0")->run()->getAll();

        $tcash = "0.00";

        if (!$result) $tcash = 0.00;
        else if ($result == null) $tcash = 0.00;
        else if ($result == "") $tcash = 0.00;
        else if ($result == "no-record") $tcash = 0.00;
        else{
            foreach ($result as $item) {
                $tcash += $item["price"];
            }
        }

        return number_format($tcash, 2, ".");
    }



    protected function _getChartData(){
        $b_7_date = date("Y-m-d", strtotime('-7 day',strtotime(date("Y-m-d"))));
        $b_6_date = date("Y-m-d", strtotime('-6 day',strtotime(date("Y-m-d"))));
        $b_5_date = date("Y-m-d", strtotime('-2 day',strtotime(date("Y-m-d"))));
        $b_4_date = date("Y-m-d", strtotime('-4 day',strtotime(date("Y-m-d"))));
        $b_3_date = date("Y-m-d", strtotime('-1 day',strtotime(date("Y-m-d"))));
        $b_2_date = date("Y-m-d", strtotime('-2 day',strtotime(date("Y-m-d"))));
        $b_1_date = date("Y-m-d", strtotime('-1 day',strtotime(date("Y-m-d"))));
        $today_date = date("Y-m-d");


        $b_7_day    = $this->_getPaymentPriceFromDate($b_7_date);
        $b_6_day    = $this->_getPaymentPriceFromDate($b_6_date);
        $b_5_day    = $this->_getPaymentPriceFromDate($b_5_date);
        $b_4_day    = $this->_getPaymentPriceFromDate($b_4_date);
        $b_3_day    = $this->_getPaymentPriceFromDate($b_3_date);
        $b_2_day    = $this->_getPaymentPriceFromDate($b_2_date);
        $b_1_day    = $this->_getPaymentPriceFromDate($b_1_date);
        $today      = $this->_getPaymentPriceFromDate($today_date);

        return [[$b_7_date, $b_7_day], [$b_6_date, $b_6_day], [$b_5_date, $b_5_day], [$b_4_date, $b_4_day], [$b_3_date, $b_3_day], [$b_2_date, $b_2_day], [$b_1_date, $b_1_day], [$today_date, $today]];
    }
}