<?php


class VAKIFBankPayment
{
    public static function CreateInstance()
    {
        return new VAKIFBankPayment();
    }

    public function create_pay($order_id, $price, $currency_unit, $ccname, $ccnumber, $ccyear, $ccmonth, $cccvv)
    {
        $bankID = "3";

        $result = \DATABASE\FFDatabase::cfun()->select("payment_gates")->where("bank_id", $bankID)->run()->get();

        if ($result == "" || $result == null || $result == false)
            return die("Database problem #9sa5d8400");

        $result2 = json_decode($result["param_keys"]);

        $mpiServiceUrl= "https://3dsecure.vakifbank.com.tr:443/MPIAPI/MPI_Enrollment.aspx"; // Dokümandaki Enrollment URLi
        $krediKartiNumarasi = $ccnumber;
        $sonKullanmaTarihi = $ccyear.$ccmonth;
        $kartTipi = "1";

        $tutar = $price;

        $cvv = $cccvv;
        $paraKodu = $currency_unit;
        $taksitSayisi = "1";
        $islemNumarasi = $order_id;
        $uyeIsyeriNumarasi = $result2->merchant_id;
        $uyeIsYeriSifresi = $result2->merchant_password;

        $SuccessURL = configs_host_ssl . "://" . configs_host_domain . "/api/payment_back/" . $bankID;    //Islem basariliysa d�n�lecek isyeri sayfasi  (3D isleminin ve �deme isleminin sonucu)
        $FailureURL = configs_host_ssl . "://" . configs_host_domain . "/api/payment_back/" . $bankID;  //Islem basarizsa d�n�lecek isyeri sayfasi  (3D isleminin ve �deme isleminin sonucu)

        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL,$mpiServiceUrl);
        curl_setopt($ch,CURLOPT_POST,TRUE);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
        curl_setopt($ch,CURLOPT_HTTPHEADER,array("Content-Type"=>"application/x-www-form-urlencoded"));
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,TRUE);
        curl_setopt($ch,CURLOPT_POSTFIELDS,"Pan=$krediKartiNumarasi&ExpiryDate=$sonKullanmaTarihi&PurchaseAmount=$tutar&Currency=$paraKodu&BrandName=$kartTipi&VerifyEnrollmentRequestId=$islemNumarasi&MerchantId=$uyeIsyeriNumarasi&MerchantPassword=$uyeIsYeriSifresi&SuccessUrl=$SuccessURL&FailureUrl=$FailureURL");


        $resultXml = curl_exec($ch);
        curl_close($ch);




        $xml= simplexml_load_string(strval($resultXml)) or die("Error: Cannot create object");

        if (isset($xml->Message->VERes->Status) && strtolower($xml->Message->VERes->Status) != "y")
            die("Lütfen Yeni Tahsilat Oluşturunuz (Tahsilat Numarası Kullanımda) <br> Eğer hatayı tekrarlı alıyorsanız transaction id hash güncelleyin bilmiyor iseniz yöneticinize başvurunuz!");


        $result = \DATABASE\FFDatabase::cfun()->update("payment_requests", [["temp_cvv", $cccvv]])->where("id", substr($order_id, strlen(configs_payment_backtr)))->run();



        ?>

        <form style="display: none; visibility: hidden;" action="<?php echo $xml->Message->VERes->ACSUrl; ?>" method="post" name="pform">
            <input style="display: none; visibility: hidden;" type="submit" value="Submit">
            <input type="hidden" name="PaReq" value="<?php echo $xml->Message->VERes->PaReq; ?>">
            <input type="hidden" name="TermUrl" value="<?php echo $xml->Message->VERes->TermUrl; ?>">
            <input type="hidden" name="MD" value="<?php echo $xml->Message->VERes->MD; ?>">
        </form>

        <script>
            document.pform.submit();
        </script>

        <?php

    }
}


?>