<?php

use Router\Router;


//echo $_POST["Status"] . "<br>";

print_r($_POST);

if (strtolower($_POST["Status"]) == "y") {

    $bankID = "3";

    $result = \DATABASE\FFDatabase::cfun()->select("payment_gates")->where("bank_id", $bankID)->run()->get();

    $result2 = \DATABASE\FFDatabase::cfun()->select("payment_requests")->where("id", substr($_POST["VerifyEnrollmentRequestId"], strlen(configs_payment_backtr)))->run()->get();


    if ($result == "" || $result == null || $result == false)
        return die("Database problem #9sa5d8400");

    if ($result2 == "" || $result2 == null || $result2 == false)
        return die("Database problem #9sa5d8400");

    $result_ = json_decode($result["param_keys"]);


    $mpiServiceUrl = "https://onlineodeme.vakifbank.com.tr:4443/VposService/v3/Vposreq.aspx"; // Dokümandaki Enrollment URLi
    $sonKullanmaTarihi = "20" . $_POST["Expiry"];
    $tutar = $result2["price"];
    $paraKodu = "949";
    $taksitSayisi = 1;
    $islemNumarasi = $_POST["VerifyEnrollmentRequestId"];
    $uyeIsyeriNumarasi = $result_->merchant_id;
    $uyeIsYeriSifresi = $result_->merchant_password;
    $SuccessURL = configs_host_ssl . "://" . configs_host_domain . "/api/payment_back/" . $bankID;    //Islem basariliysa d�n�lecek isyeri sayfasi  (3D isleminin ve �deme isleminin sonucu)
    $FailureURL = configs_host_ssl . "://" . configs_host_domain . "/api/payment_back/" . $bankID;  //Islem basarizsa d�n�lecek isyeri sayfasi  (3D isleminin ve �deme isleminin sonucu)

    $Pan = $_POST["Pan"];
    $Cvv = $result2["temp_cvv"];

    $Eci = $_POST["Eci"];
    $Cavv = $_POST["Cavv"];
    $mpID = $_POST["VerifyEnrollmentRequestId"];
    $ip = $_SERVER["REMOTE_ADDR"];


    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $mpiServiceUrl);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type" => "application/x-www-form-urlencoded"));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

    curl_setopt($ch, CURLOPT_POSTFIELDS, 'prmstr=<VposRequest> <MerchantId>' . $uyeIsyeriNumarasi . '</MerchantId> <Password>' . $uyeIsYeriSifresi . '</Password> <TerminalNo>VP124808</TerminalNo> <TransactionType>Sale</TransactionType> <TransactionId> ' . $islemNumarasi . '</TransactionId> <CurrencyAmount>' . $tutar . '</CurrencyAmount> <CurrencyCode>949</CurrencyCode> <Pan>' . $Pan . '</Pan> <Cvv>' . $Cvv . '</Cvv> <Expiry>' . $sonKullanmaTarihi . '</Expiry> <ECI>' . $Eci . '</ECI> <CAVV>' . $Cavv . '</CAVV> <MpiTransactionId>' . $mpID . '</MpiTransactionId> <ClientIp>' . $ip . '</ClientIp> <TransactionDeviceSource>0</TransactionDeviceSource></VposRequest>');

    $resultXml = curl_exec($ch);
    curl_close($ch);

    //$result = new SimpleXMLElement($resultXml);

    $xmlOUT = simplexml_load_string($resultXml);

    if($xmlOUT->ResultCode == "0000") {
        \DATABASE\FFDatabase::cfun()->update("payment_requests", [["status", "confirmed"], ["response_data", $xmlOUT->ResultCode . " | " . $xmlOUT->ResultDetail]])->where("id", substr($islemNumarasi, strlen(configs_payment_backtr)))->run();
        $smc = \SessionController\SessionController::CreateInstance();

        $smc->Set("PAYMENT_PAGE_PAY_ID_STATUS","success");
        $smc = null;

        Router::Route("success");
    }
    else{
        \DATABASE\FFDatabase::cfun()->update("payment_requests", [["status", "refused"], ["response_data", $xmlOUT->ResultCode . " | " . $xmlOUT->ResultDetail]])->where("id", substr($islemNumarasi, strlen(configs_payment_backtr)))->run();

        $smc = \SessionController\SessionController::CreateInstance();

        $smc->Set("PAYMENT_PAGE_PAY_ID_STATUS","unsuccess");
        $smc = null;

        Router::Route("unsuccess");
    }


    //echo $xmlOUT->ResultCode . " | ";
    //echo $xmlOUT->ResultDetail;
}