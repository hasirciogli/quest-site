<?php

use Router\Router;

if($_POST["3DStatus"] == "1" && $_POST["ProcReturnCode"] == "00")
{
    \DATABASE\FFDatabase::cfun()->update("payment_requests", [["status", "confirmed"], ["response_data", $_POST["ErrMsg"]]])->where("id", substr($_POST["OrderId"], strlen(configs_payment_backtr)))->run();
    $smc = \SessionController\SessionController::CreateInstance();

    $smc->Set("PAYMENT_PAGE_PAY_ID_STATUS","success");
    $smc = null;

    Router::Route("success");
}
else
{

    \DATABASE\FFDatabase::cfun()->update("payment_requests", [["status", "refused"], ["response_data", $_POST["ErrMsg"]]])->where("id", substr($_POST["OrderId"], strlen(configs_payment_backtr)))->run();

    $smc = \SessionController\SessionController::CreateInstance();

    $smc->Set("PAYMENT_PAGE_PAY_ID_STATUS","unsuccess");
    $smc = null;

    Router::Route("unsuccess");
}


?>