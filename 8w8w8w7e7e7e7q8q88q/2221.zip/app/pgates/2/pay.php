<?php

use DataLogger\DataLogger;
use DataLogger\DATALOGGER_LOG_TYPE;

class FinansbankPayment
{

    public static function CreateInstance()
    {
        $temp_result = DataLogger::cfun()->logData(DATALOGGER_LOG_TYPE::PAYMENT_GATES_LOG, "Payment Gates Instance Created", "public static function CreateInstance() at ". date("Y-m-d H-i-s"));
        $temp_result = null;
        return new FinansbankPayment();
    }

    public function create_pay($order_id, $price, $currency_unit, $ccname, $ccnumber, $ccyear, $ccmonth, $cccvv)
    {
        $bankID = "2";

        $result = \DATABASE\FFDatabase::cfun()->select("payment_gates")->where("bank_id", $bankID)->run()->get();

        if ($result == "" || $result == null || $result == false)
            return die("Database problem #9sa5d8400");

        $result2 = json_decode($result["param_keys"]);


        $MbrId = "2";   //Kurum Kodu


        $MerchantID     = $result["test_mode"] ?       "085300000009597"       : $result2->merchant_id;
        $MerchantPass   = $result["test_mode"] ?       "12345678"              : $result2->merchant_pass;
        $UserCode       = $result["test_mode"] ?       "QNB_API_KULLANICI"     : $result2->user_id;
        $UserPass       = $result["test_mode"] ?       "FwCX2"                 : $result2->user_pass;



        $temp_result = DataLogger::cfun()->logData(DATALOGGER_LOG_TYPE::PAYMENT_REQUEST_PAY_LOG, "Payment Gates Instance Created", json_encode([
            "bank_id"                   => $bankID,
            "bank_name"                 => $result["bank_name"],
            "order_id"                  => $order_id,
            "order_price"               => $price,
            "currency_unit"             => $currency_unit,
            "credit_card_holder_name"   => $ccname,
            "credit_card_number"        => $ccnumber,
            "credit_card_expiry_year"   => $ccyear,
            "credit_card_expiry_month"  => $ccmonth,
            "credit_card_cvv2"          => $cccvv,
            "LOG_CREATED_AT"          => date("Y-m-d H-i-s")
        ], JSON_UNESCAPED_UNICODE));

        $temp_result = null;




        $SecureType = "3DPay";    // Güvenlik tipi
        $TxnType = "Auth";    // İşlem Tipi
        $InstallmentCount = "0";   // Taksit Sayısı
        $Currency = $currency_unit;  // Para Birimis 949:TL | 840:USD
        $OkUrl = configs_host_ssl . "://" . configs_host_domain . "/api/payment_back/" . $bankID;    //Islem basariliysa d�n�lecek isyeri sayfasi  (3D isleminin ve �deme isleminin sonucu)
        $FailUrl = configs_host_ssl . "://" . configs_host_domain . "/api/payment_back/" . $bankID;  //Islem basarizsa d�n�lecek isyeri sayfasi  (3D isleminin ve �deme isleminin sonucu)

        $OrderId = $order_id; // Sipariş numarası
        $OrgOrderId = "";   // HİÇ GEREK YOK BOŞ PARAMETRE
        $PurchAmount = $price;   // NE KADAR ÇEKİLECEK KARTTAN O PARA
        $Lang = "TR"; // ÖDEME VEYA 3D SAYFASI DİLİ
        $rnd = microtime();
        $hashstr = $MbrId . $OrderId . $PurchAmount . $OkUrl . $FailUrl . $TxnType . $InstallmentCount . $rnd . $MerchantPass;
        $hash = base64_encode(pack('H*', sha1($hashstr)));

        ?>

        <form method="post" action="<?php echo $result["test_mode"] ? "https://vpostest.qnbfinansbank.com/Gateway/Default.aspx" : "https://vpos.qnbfinansbank.com/Gateway/Default.aspx";?>">
            <input type="submit" style="display: none; visibility: hidden" class="hidden" id="submit_button">
            <input type="hidden" name="Pan" maxlength="19" class="inputClass" value="<?php echo $ccnumber; ?>">
            <input type="hidden" name="Cvv2" maxlength="4" class="inputClass" value="<?php echo $cccvv; ?>">
            <input type="hidden" name="Expiry" maxlength="4" class="inputClass" value="<?php echo $ccmonth.$ccyear; ?>">
            <input type="hidden" name="MbrId" value="<?php echo $MbrId ?>">
            <input type="hidden" name="MerchantID" value="<?php echo $MerchantID ?>">
            <input type="hidden" name="UserCode" value="<?php echo $UserCode ?>">
            <input type="hidden" name="UserPass" value="<?php echo $UserPass ?>">
            <input type="hidden" name="SecureType" value="<?php echo $SecureType ?>">
            <input type="hidden" name="TxnType" value="<?php echo $TxnType ?>">
            <input type="hidden" name="InstallmentCount" value="<?php echo $InstallmentCount ?>">
            <input type="hidden" name="Currency" value="<?php echo $Currency ?>">
            <input type="hidden" name="OkUrl" value="<?php echo $OkUrl ?>">
            <input type="hidden" name="FailUrl" value="<?php echo $FailUrl ?>">
            <input type="hidden" name="OrderId" value="<?php echo $OrderId ?>">
            <input type="hidden" name="OrgOrderId" value="<?php echo $OrgOrderId ?>">
            <input type="hidden" name="PurchAmount" value="<?php echo $PurchAmount ?>">
            <input type="hidden" name="Lang" value="<?php echo $Lang ?>">
            <input type="hidden" name="Rnd" value="<?php echo $rnd ?>">
            <input type="hidden" name="Hash" value="<?php echo $hash ?>">
        </form>

        <script>
            document.getElementById("submit_button").click();
        </script>

        <?php ;
    }
}


?>