<?php

class QNBFINANSBankRefunder {

    public static function cfun()
    {
        return new QNBFINANSBankRefunder();
    }

    public function CreateRefund($internal_payment_id, $bank_payment_id, $refund_price){

        header("Content-Type: text/html");

        $bankID = "2";

        $result = \DATABASE\FFDatabase::cfun()->select("payment_gates")->where("bank_id", $bankID)->run()->get();

        if ($result == "" || $result == null || $result == false)
            return die("Database problem #89789234/as4a8-*2özxjmfşkksgehn");

        $result2 = json_decode($result["param_keys"]);


        $merchant_id    = $result["test_mode"]     ?   "085300000009597"       :   $result2->merchant_id;
        $merchant_pass  = $result["test_mode"]     ?   "12345678"              :   $result2->merchant_pass;
        $user_id        = $result["test_mode"]     ?   "QNB_API_KULLANICI"     :   $result2->user_id;
        $user_pass      = $result["test_mode"]     ?   "FwCX2"                 :   $result2->user_pass;


        $data = "".
            "MbrId=2&".
            //Kurum Kodu
            "MerchantID=".$merchant_id."&".
            //Üye işyeri numarası
            "UserCode=".$user_id."&".
            //Kullanıcı Kodu
            "UserPass=".$user_pass."&".
            //Kullanıcı Şifre
            "OrderId=".$bank_payment_id."&".
            // İşlem  Sipariş numarası
            "SecureType=NonSecure&".
            //Güvenlik tipi
            "TxnType=Refund&".
            //İşlem Tipi
            "PurchAmount=" . $refund_price . "&".
            //Tutar
            "Currency=949&".
            //Para Birimi
            "Lang=TR&";
            //Dil bilgisi
            $url = $result["test_mode"] ? "https://vpostest.qnbfinansbank.com/Gateway/Default.aspx" : "https://vpos.qnbfinansbank.com/Gateway/Default.aspx";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
        curl_setopt($ch, CURLOPT_SSLVERSION, 6);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 90);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $result = curl_exec($ch);

        if (curl_errno($ch)) {
            print curl_error($ch);
        } else {
            curl_close($ch);
        }


        foreach (explode(";;", $result) as $key => $value)
        {
            $data = explode("=", $value);
            $datakey = $data[0];
            $dataval = $data[1];

            $rdata[$datakey] = $dataval;
        }

        $response_code  = $rdata["ProcReturnCode"];
        $response_msg   = $rdata["ErrMsg"];

        if ($response_code == "00")
        {
            $this->SetRefundToPayment1($internal_payment_id);
            // TODO: Iade başarıyla gerçekleştirildi :))
        }
        else{
            switch ($response_code)
            {
                case "V037":
                    // İşlem zaten iade edilmiş o yüzden veritabanında direkt "refunded" olarak işaretlenmek üzerine veritabanı işlemi başlatılır.
                    $this->SetRefundToPayment1($internal_payment_id);
                    break;

                case "V014":
                    // Günsonu yapılmamış işlemler bu hata kodunu iletir ve direkt ana işlem iptal olarak gönderilmelidir.
                    $this->CancelPaymentBeforeDayBack($internal_payment_id, $bank_payment_id, $merchant_id, $merchant_pass, $user_id, $user_pass, $url);
                    break;

                default:
                    // iade cidden başarısız...
                    //$this->SetRefundToPayment1($internal_payment_id);
                    break;
            }
            // TODO: Iade maalesef başarısız :(
        }
    }

    public function CancelPaymentBeforeDayBack($internal_payment_id, $bank_payment_id, $merchant_id, $merchant_pass, $user_id, $user_pass, $url){
        $data = "".
            "MbrId=2&".
            //Kurum Kodu
            "MerchantID=".$merchant_id."&".
            //Üye işyeri numarası
            "UserCode=".$user_id."&".
            //Kullanıcı Kodu
            "UserPass=".$user_pass."&".
            //Kullanıcı Şifre
            "OrderId=".$bank_payment_id."&".
            // İşlem  Sipariş numarası
            "SecureType=NonSecure&".
            //Güvenlik tipi
            "TxnType=Void&".
            //İşlem Tipi
            "Currency=949&".
            //Para Birimi
            "Lang=TR&";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
        curl_setopt($ch, CURLOPT_SSLVERSION, 6);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 90);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $result2 = curl_exec($ch);

        if (curl_errno($ch)) {
            print curl_error($ch);
        } else {
            curl_close($ch);
        }

        foreach (explode(";;", $result2) as $key => $value)
        {
            $data = explode("=", $value);
            $datakey = $data[0];
            $dataval = $data[1];

            $rdata2[$datakey] = $dataval;
        }

        $gs_iptal_code  = $rdata2["ProcReturnCode"];
        $gs_iptal_msg   = $rdata2["ErrMsg"];

        if ($gs_iptal_code == "00"){
            $this->SetRefundToPayment1($internal_payment_id);
        }
        else{
            die("BIG ERROR PLEASE CALL THE CODER RIGHT NOW! 0x4588795446845124845121541245");
        }
    }

    public function SetRefundToPayment1($internal_payment_id){
        \DATABASE\FFDatabase::cfun()->update("payment_requests", [["status","refunded"]])->where("id", $internal_payment_id)->run();
    }
}