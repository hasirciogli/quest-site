<?php
use Router\Router;
$AuthenticationResponse = $_POST["AuthenticationResponse"];
$RequestContent = urldecode($AuthenticationResponse);
$xxml = simplexml_load_string($RequestContent) or die("Error: Cannot create object");
print_r($xxml);
die(print_r($_POST));

$mdStatus = $_POST["mdStatus"];
$ErrMsg = $_POST["ErrMsg"];
if($mdStatus == 1 || $mdStatus == 2 || $mdStatus == 3 || $mdStatus == 4)
{
    $response = $_POST["Response"];
    if($response == "Approved")
    {
        // TODO: ÖDEME İŞLEMİ BAŞARILI

        \DATABASE\FFDatabase::cfun()->update("payment_requests", [["status", "confirmed"], ["response_data", @$_POST["ErrMsg"] . " | err2-> " . @$_POST["mdErrorMsg"]]])->where("id", substr($_POST["oid"], strlen(configs_payment_backtr)))->run();
        $smc = \SessionController\SessionController::CreateInstance();

        $smc->Set("PAYMENT_PAGE_PAY_ID_STATUS","success");
        $smc = null;

        Router::Route("success");
    }
    else
    {
        // TODO: ÖDEME İŞLEMİ BAŞARISIZ

        \DATABASE\FFDatabase::cfun()->update("payment_requests", [["status", "refused"], ["response_data", @$_POST["ErrMsg"] . " | err2-> " . @$_POST["mdErrorMsg"]]])->where("id", substr($_POST["oid"], strlen(configs_payment_backtr)))->run();

        $smc = \SessionController\SessionController::CreateInstance();

        $smc->Set("PAYMENT_PAGE_PAY_ID_STATUS","unsuccess");
        $smc = null;

        Router::Route("unsuccess");

    }

}
else
{
    // TODO: ÖDEME İŞLEMİ BAŞARISIZ

    \DATABASE\FFDatabase::cfun()->update("payment_requests", [["status", "refused"], ["response_data", $_POST["ErrMsg"]]])->where("id", substr($_POST["OrderId"], strlen(configs_payment_backtr)))->run();

    $smc = \SessionController\SessionController::CreateInstance();

    $smc->Set("PAYMENT_PAGE_PAY_ID_STATUS","unsuccess");
    $smc = null;

    Router::Route("unsuccess");

}