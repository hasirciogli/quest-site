<?php


class KUVEYTTURKPayment
{

    public static function CreateInstance()
    {
        return new KUVEYTTURKPayment();
    }

    public function create_pay($order_id, $price, $currency_unit, $ccname, $ccnumber, $ccyear, $ccmonth, $cccvv)
    {
        $bankID = "6";

        $result = \DATABASE\FFDatabase::cfun()->select("payment_gates")->where("bank_id", $bankID)->run()->get();

        if ($result == "" || $result == null || $result == false)
            return die("Database problem #9sa5d8400");

        $result2 = json_decode($result["param_keys"]);

        switch ($currency_unit){
            case "949":
                $currency_unit = "0949";
                break;
            default:
                break;
        }

        $Name = $ccname;
        $CardNumber = $ccnumber;
        $CardExpireDateMonth = $ccmonth;
        $CardExpireDateYear = $ccyear;
        $CardCVV2 = $cccvv;
        $MerchantOrderId = $order_id; // Siparis Numarasi
        $Amount = explode(".", $price)[0]; //$price;
        $CustomerId = $result["test_mode"] ? "400235" : $result2->customer_id;
        $MerchantId = $result["test_mode"] ? "496" : $result2->merchant_id;
        $OkUrl = configs_host_ssl . "://" . configs_host_domain . "/api/payment_back/" . $bankID;
        $FailUrl = configs_host_ssl . "://" . configs_host_domain . "/api/payment_back/" . $bankID;
        $UserName = $result["test_mode"] ? "apitest" : $result2->username;
        $Password = $result["test_mode"] ? "api123" : $result2->password;
        $HashedPassword = base64_encode(sha1($Password, "ISO-8859-3")); //md5($Password);
        $HashData = base64_encode(sha1($MerchantId . $MerchantOrderId . $Amount . $OkUrl . $FailUrl . $UserName . $HashedPassword, "ISO-8859-3"));
        $xml = '<KuveytTurkVPosMessage xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            . '<APIVersion>1.0.0</APIVersion>'
            . '<OkUrl>' . $OkUrl . '</OkUrl>'
            . '<FailUrl>' . $FailUrl . '</FailUrl>'
            . '<SubMerchantId>0</SubMerchantId>'
            . '<HashData>' . $HashData . '</HashData>'
            . '<MerchantId>' . $MerchantId . '</MerchantId>'
            . '<CustomerId>' . $CustomerId . '</CustomerId>'
            . '<UserName>' . $UserName . '</UserName>'
            . '<CardNumber>' . $CardNumber . '</CardNumber>'
            . '<CardExpireDateYear>' . $CardExpireDateYear . '</CardExpireDateYear>'
            . '<CardExpireDateMonth>' . $CardExpireDateMonth . '</CardExpireDateMonth>'
            . '<CardCVV2>' . $CardCVV2 . '</CardCVV2>'
            . '<CardHolderName>' . $Name . '</CardHolderName>'
            . '<InstallmentCount>0</InstallmentCount>'
            . '<DeferringCount>1</DeferringCount>'
            . '<CardType>VISA</CardType>'
            . '<BatchID>0</BatchID>'
            . '<TransactionType>Sale</TransactionType>'
            . '<Amount>' . $Amount . '</Amount>'
            . '<DisplayAmount>' . $Amount . '</DisplayAmount>'
            . '<CurrencyCode>' . $currency_unit . '</CurrencyCode>'
            . '<MerchantOrderId>' . $MerchantOrderId . '</MerchantOrderId>'
            . '<TransactionSecurity>1</TransactionSecurity>'
            . '<TransactionSide>Sale</TransactionSide>'
            . '</KuveytTurkVPosMessage>';


        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSLVERSION, 6);
            curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_MAX_TLSv1_2); // alternatif
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/xml', 'Content-length: '. strlen($xml)) );
            curl_setopt($ch, CURLOPT_POST, true); //POST Metodu kullanarak verileri gönder
            curl_setopt($ch, CURLOPT_HEADER, false); //Serverdan gelen Header bilgilerini önemseme.
            curl_setopt($ch,CURLOPT_URL,$result["test_mode"] ? 'https://boatest.kuveytturk.com.tr/boa.virtualpos.services/Home/ThreeDModelPayGate' : "https://sanalpos.kuveytturk.com.tr/ServiceGateWay/Home/ThreeDModelPayGate");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); //Transfer sonuçlarini al.
            $data = curl_exec($ch);
            curl_close($ch);
        }
        catch (Exception $e)
        {
            echo 'Caught exception: ', $e->getMessage(), "\n";
        }

        die($data);
    }
}


?>