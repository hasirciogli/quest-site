<?php


class INGBankPayment
{

    public static function CreateInstance()
    {
        return new INGBankPayment();
    }

    public function create_pay($order_id, $price, $currency_unit, $ccname, $ccnumber, $ccyear, $ccmonth, $cccvv)
    {
        $bankID = "4";

        $result = \DATABASE\FFDatabase::cfun()->select("payment_gates")->where("bank_id", $bankID)->run()->get();

        if ($result == "" || $result == null || $result == false)
            return die("Database problem #9sa5d8400");

        $result2 = json_decode($result["param_keys"]);

        $clientId = $result["test_mode"] ?  "150150300" : $result2->client_id;    //Banka tarafindan verilen isyeri numarasi
        $amount = $price;                   //Islem tutari
        $oid = $order_id;                   //Siparis Numarasi

        $okUrl = configs_host_ssl . "://" . configs_host_domain . "/api/payment_back/" . $bankID;    //Islem basariliysa d�n�lecek isyeri sayfasi  (3D isleminin ve �deme isleminin sonucu)
        $failUrl = configs_host_ssl . "://" . configs_host_domain . "/api/payment_back/" . $bankID;  //Islem basarizsa d�n�lecek isyeri sayfasi  (3D isleminin ve �deme isleminin sonucu)

        $rnd = microtime();    //Tarih veya her seferinde degisen bir deger g�venlik ama�li
        $taksit = "";         //taksit sayisi
        $islemtipi="Auth";     //Islem tipi
        $storekey =  $result["test_mode"] ? "TRPS1234" : $result2->store_key;  //isyeri anahtari

// hash hesabinda taksit ve islemtipi de kullanilir.

        $hashstr = $clientId . $oid . $amount . $okUrl . $failUrl .$islemtipi. $taksit  .$rnd . $storekey;


        $hash = base64_encode(pack('H*',sha1($hashstr)));

        ?>

        <form method="post" action="<?php echo $result["test_mode"] ? "https://entegrasyon.asseco-see.com.tr/fim/est3Dgate" : "https://sanalpos.ingbank.com.tr/fim/est3Dgate";?>">
            <input type="hidden" name="pan" value="<?php echo $ccnumber ?>">
            <input type="hidden" name="cv2" size="4" value="<?php echo $cccvv ?>"/>
            <input type="hidden" name="Ecom_Payment_Card_ExpDate_Year" value="<?php echo $ccyear ?>"/>
            <input type="hidden" name="Ecom_Payment_Card_ExpDate_Month" value="<?php echo $ccmonth ?>"/>
            <input type="hidden" name="cardType" value="1"/> // 1 visa 2 mastercard
            <input type="hidden" name="clientid" value="<?php  echo $clientId ?>">
            <input type="hidden" name="amount" value="<?php  echo $amount ?>">
            <input type="hidden" name="oid" value="<?php  echo $oid ?>">
            <input type="hidden" name="okUrl" value="<?php  echo $okUrl ?>">
            <input type="hidden" name="failUrl" value="<?php  echo $failUrl ?>">
            <input type="hidden" name="rnd" value="<?php  echo $rnd ?>" >
            <input type="hidden" name="hash" value="<?php  echo $hash ?>" >
            <input type="hidden" name="islemtipi" value="<?php echo $islemtipi ?>" >
            <input type="hidden" name="taksit" value="<?php echo $taksit ?>" >
            <input type="hidden" name="storetype" value="<?php $result["test_mode"] ? "3d_pay_hosting" : "3d_pay_hosting"; ?>">
            <input type="hidden" name="lang" value="tr">
            <input type="submit" style="display: none; visibility: hidden;" id="submit_button">
        </form>

        <script>
            document.getElementById("submit_button").click();
        </script>

        <?php ;
    }
}


?>