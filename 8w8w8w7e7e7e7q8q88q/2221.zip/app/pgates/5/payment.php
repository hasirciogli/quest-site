<?php

use Router\Router;
//die(print_r($_POST));

$mdStatus = $_POST["mdStatus"] ?? null;
$ErrMsg = $_POST["ErrMsg"] ?? null;

if($mdStatus == 1 || $mdStatus == 2 || $mdStatus == 3 || $mdStatus == 4)
{
    $response = $_POST["Response"] ?? null;
    if($response == "Approved")
    {
        // TODO: ÖDEME İŞLEMİ BAŞARILI

        \DATABASE\FFDatabase::cfun()->update("payment_requests", [["status", "confirmed"], ["response_data", ($_POST["mdErrorMsg"] ?? null) . " | err2-> " . ($_POST["mdStatus"] ?? null)]])->where("id", substr($_POST["oid"], strlen(configs_payment_backtr)))->run();
        $smc = \SessionController\SessionController::CreateInstance();

        $smc->Set("PAYMENT_PAGE_PAY_ID_STATUS","success");
        $smc = null;

        Router::Route("success");
    }
    else
    {
        // TODO: ÖDEME İŞLEMİ BAŞARISIZ

        \DATABASE\FFDatabase::cfun()->update("payment_requests", [["status", "refused"], ["response_data", ($_POST["ErrMsg"] ?? null) . " | err2-> " . ($_POST["mdStatus"] ?? null)]])->where("id", substr($_POST["oid"], strlen(configs_payment_backtr)))->run();

        $smc = \SessionController\SessionController::CreateInstance();

        $smc->Set("PAYMENT_PAGE_PAY_ID_STATUS","unsuccess");
        $smc = null;

        Router::Route("unsuccess");

    }

}
else
{
    // TODO: ÖDEME İŞLEMİ BAŞARISIZ

    \DATABASE\FFDatabase::cfun()->update("payment_requests", [["status", "refused"], ["response_data", $_POST["mdErrorMsg"] ?? null]])->where("id", substr($_POST["oid"], strlen(configs_payment_backtr)))->run();

    $smc = \SessionController\SessionController::CreateInstance();

    $smc->Set("PAYMENT_PAGE_PAY_ID_STATUS","unsuccess");
    $smc = null;

    Router::Route("unsuccess");

}