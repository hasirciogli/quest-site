<?php


class SEKERBankPayment
{

    public static function CreateInstance()
    {
        return new SEKERBankPayment();
    }

    public function create_pay($order_id, $price, $currency_unit, $ccname, $ccnumber, $ccyear, $ccmonth, $cccvv)
    {
        $bankID = "5";

        $result = \DATABASE\FFDatabase::cfun()->select("payment_gates")->where("bank_id", $bankID)->run()->get();

        if ($result == "" || $result == null || $result == false)
            return die("Database problem #9sa5d8400");

        $result2 = json_decode($result["param_keys"]);

        $clientId = $result2->client_id;    //Banka tarafindan verilen isyeri numarasi
        $amount = $price;                   //Islem tutari
        $oid = $order_id;                   //Siparis Numarasi

        $okUrl = configs_host_ssl . "://" . configs_host_domain . "/api/payment_back/" . $bankID;    //Islem basariliysa d�n�lecek isyeri sayfasi  (3D isleminin ve �deme isleminin sonucu)
        $failUrl = configs_host_ssl . "://" . configs_host_domain . "/api/payment_back/" . $bankID;  //Islem basarizsa d�n�lecek isyeri sayfasi  (3D isleminin ve �deme isleminin sonucu)

        $rnd = microtime();    //Tarih veya her seferinde degisen bir deger g�venlik ama�li
        $taksit = "";         //taksit sayisi
        $islemtipi="Auth";     //Islem tipi
        $storekey = $result2->store_key;  //isyeri anahtari

        // hash hesabinda taksit ve islemtipi de kullanilir.

        $hashstr = $clientId . $oid . $amount . $okUrl . $failUrl .$islemtipi. $taksit  .$rnd . $storekey;


        $hash = base64_encode(pack('H*',sha1($hashstr)));

        ?>

        <form method="post" action="<?php echo $result["test_mode"] ? "https://entegrasyon.asseco-see.com.tr/fim/est3Dgate" : "https://sanalpos.sekerbank.com.tr/fim/est3dgate";?>">
            <input type="" name="pan" value="<?php echo $ccnumber ?>">
            <input type="" name="cv2" size="4" value="<?php echo $cccvv ?>"/>
            <input type="" name="Ecom_Payment_Card_ExpDate_Year" value="<?php echo "20".$ccyear ?>"/>
            <input type="" name="Ecom_Payment_Card_ExpDate_Month" value="<?php echo $ccmonth ?>"/>
            <input type="" name="cardType" value="0"/>
            <input type="" name="clientid" value="<?php  echo $clientId ?>">
            <input type="" name="amount" value="<?php  echo $amount ?>">
            <input type="" name="oid" value="<?php  echo $oid ?>">
            <input type="" name="okUrl" value="<?php  echo $okUrl ?>">
            <input type="" name="failUrl" value="<?php  echo $failUrl ?>">
            <input type="" name="rnd" value="<?php  echo $rnd ?>" >
            <input type="" name="hash" value="<?php  echo $hash ?>" >
            <input type="" name="islemtipi" value="<?php echo $islemtipi ?>" >
            <input type="" name="taksit" value="<?php echo $taksit ?>" >
            <input type="" name="storetype" value="3d_pay">
            <input type="" name="lang" value="tr">
            <input type="submit" id="submit_button" value="12">
        </form>

        <script>
            document.getElementById("submit_button").click();
        </script>

        <?php ;
    }
}


?>