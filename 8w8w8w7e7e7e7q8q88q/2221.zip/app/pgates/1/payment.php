<?php

use Router\Router;


$Status = $_POST["3DStatus"];
$ErrMsg = $_POST["ErrorMessage"];

if($Status == 1 || $Status == 2 || $Status == 3 || $Status == 4)
{
    // TODO: 3D DOĞULAMA BAŞARILI;

    $response = $_POST["ProcReturnCode"];
    if($response == "00")
    {
        // TODO: ÖDEME BAŞARILI;
        paymentSuccess();
    }
    else
    {
        // TODO: ÖDEME BAŞARISIZ;
        paymentFailed();
    }

}
else
{
    // TODO: 3D DOĞULAMA BAŞARISIZ;
    paymentFailed();
}


function paymentFailed(){
    \DATABASE\FFDatabase::cfun()->update("payment_requests", [["status", "refused"], ["response_data", $_POST["ErrorMessage"]]])->where("id", substr($_POST["OrderId"], strlen(configs_payment_backtr)))->run();

    $smc = \SessionController\SessionController::CreateInstance();

    $smc->Set("PAYMENT_PAGE_PAY_ID_STATUS","unsuccess");
    $smc = null;

    Router::Route("unsuccess");

}

function paymentSuccess(){
    \DATABASE\FFDatabase::cfun()->update("payment_requests", [["status", "confirmed"]])->where("id", substr($_POST["OrderId"], strlen(configs_payment_backtr)))->run();
    $smc = \SessionController\SessionController::CreateInstance();

    $smc->Set("PAYMENT_PAGE_PAY_ID_STATUS","success");
    $smc = null;

    Router::Route("success");

}