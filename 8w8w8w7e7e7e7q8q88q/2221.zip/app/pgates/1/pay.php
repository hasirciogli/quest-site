<?php


class DENIZBankPayment
{

    public static function CreateInstance()
    {
        return new DENIZBankPayment();
    }

    public function create_pay($order_id, $price, $currency_unit, $ccname, $ccnumber, $ccyear, $ccmonth, $cccvv)
    {
        $bankID = "1";

        $result = \DATABASE\FFDatabase::cfun()->select("payment_gates")->where("bank_id", $bankID)->run()->get();

        if ($result == "" || $result == null || $result == false)
            return die("Database problem #9sa5d8400");

        $result2 = json_decode($result["param_keys"]);



        $shopCode = $result["test_mode"] ? "3123" : $result2->shop_code;  //Banka tarafindan verilen isyeri numarasi
        $purchaseAmount = $price;         //Islem tutari
        $orderId = $order_id;      //Siparis Numarasi
        $currency = $currency_unit; // Kur Bilgisi - 949 TL

        $okUrl = configs_host_ssl . "://" . configs_host_domain . "/api/payment_back/" . $bankID;    //Islem basariliysa d�n�lecek isyeri sayfasi  (3D isleminin ve �deme isleminin sonucu)
        $failUrl = configs_host_ssl . "://" . configs_host_domain . "/api/payment_back/" . $bankID;  //Islem basarizsa d�n�lecek isyeri sayfasi  (3D isleminin ve �deme isleminin sonucu)

        $rnd = microtime();    //Tarih veya her seferinde degisen bir deger g?venlik ama?li
        $installmentCount = "0";         //taksit sayisi
        $txnType ="Auth";     //Islem tipi
        $merchantPass = $result["test_mode"] ? "gDg1N" : $result2->merchant_pass;  //isyeri 3D anahtari
            // hash hesabinda taksit ve islemtipi de kullanilir.

        $hashstr = $shopCode . $orderId . $purchaseAmount . $okUrl . $failUrl .$txnType. $installmentCount  .$rnd . $merchantPass;


        $hash = base64_encode(pack('H*',sha1($hashstr)));

        ?>

        <?php echo $ccmonth . $ccyear; ?>
        <form method="post" action="<?php echo $result["test_mode"] ? "https://test.inter-vpos.com.tr/mpi/Default.aspx" : "https://inter-vpos.com.tr/mpi/Default.aspx"; ?>">
            <input type="text" name="Pan" size="20" value="<?php echo $ccnumber; ?>">
            <input type="text" name="Cvv2" size="4" value="<?php echo $cccvv; ?>">
            <input type="text" name="Expiry" value="<?php echo $ccmonth . $ccyear; ?>">
            <input type="text" name="BonusAmount" value="<?php echo ""; ?>">
            <input type="text" name="CardType" value="1">
            <input type="submit" id="submit_button">
            <input type="hidden" name="ShopCode" value="<?php  echo $shopCode ?>">
            <input type="hidden" name="PurchAmount" value="<?php  echo $purchaseAmount ?>">
            <input type="hidden" name="Currency" value="<?php  echo $currency ?>">
            <input type="hidden" name="OrderId" value="<?php  echo $orderId ?>">
            <input type="hidden" name="OkUrl" value="<?php  echo $okUrl ?>">
            <input type="hidden" name="FailUrl" value="<?php  echo $failUrl ?>">
            <input type="hidden" name="Rnd" value="<?php  echo $rnd ?>" >
            <input type="hidden" name="Hash" value="<?php  echo $hash ?>" >
            <input type="hidden" name="TxnType" value="<?php  echo $txnType ?>" />
            <input type="hidden" name="InstallmentCount" value="<?php  echo $installmentCount ?>" />
            <input type="hidden" name="SecureType" value="3DPay" >
            <input type="hidden" name="Lang" value="tr">
        </form>

        <script>
            document.getElementById("submit_button").click();
        </script>

        <?php ;
    }
}


?>