<?php

class DENIZBankRefunder {

    public static function cfun()
    {
        return new DENIZBankRefunder();
    }

    public function CreateRefund($internal_payment_id, $bank_payment_id, $refund_price){
        header("Content-Type: text/html");

        $bankID = "1";

        $result = \DATABASE\FFDatabase::cfun()->select("payment_gates")->where("bank_id", $bankID)->run()->get();

        if ($result == "" || $result == null || $result == false)
            return die("Database problem #89789234/as4a8-*2özxjmfşkksgehn");

        $result2 = json_decode($result["param_keys"]);


        $TestMode   = $result["test_mode"];

        $ShopCode   = $TestMode ?   "3123"              :   $result2->merchant_id;
        $UserCode   = $TestMode ?   "InterTestApi"      :   $result2->merchant_pass;
        $UserPass   = $TestMode ?   "1"                 :   $result2->user_id;


        $data = "".
            //Kurum Kodu
            "ShopCode=".$ShopCode."&".
            //Üye işyeri numarası
            "UserCode=".$UserCode."&".
            //Kullanıcı Kodu
            "UserPass=".$UserPass."&".
            "PurchAmount=".$refund_price."&".
            "Currency=949&".
            "CardType=1&".
            //Kullanıcı Şifre
            "orgOrderId=".$bank_payment_id."&".
            // İşlem  Sipariş numarası
            "SecureType=NonSecure&".
            //Güvenlik tipi
            "TxnType=Refund&".
            //Para Birimi
            "Lang=TR&";
        //Dil bilgisi
        $url = $TestMode ? "https://test.inter-vpos.com.tr/mpi/Default.aspx" : "https://inter-vpos.com.tr/mpi/Default.aspx";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
        curl_setopt($ch, CURLOPT_SSLVERSION, 6);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 90);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $result = curl_exec($ch);




        if (curl_errno($ch)) {
            print curl_error($ch);
        } else {
            curl_close($ch);
        }

        foreach (explode(";;", $result) as $key => $value)
        {
            $data = explode("=", $value);
            $datakey = $data[0];
            $dataval = $data[1];

            $rdata[$datakey] = $dataval;
        }

        $response_code  = $rdata["ProcReturnCode"];
        $response_msg   = $rdata["ErrorMessage"];

        if ($response_code == "00")
        {
            $this->SetRefundToPayment1($internal_payment_id);
            // TODO: Iade başarıyla gerçekleştirildi :))
        }
        else{
            switch ($response_code)
            {
                case "05":
                    // İşlem zaten iade edilmiş o yüzden veritabanında direkt "refunded" olarak işaretlenmek üzerine veritabanı işlemi başlatılır.
                    $this->SetRefundToPayment1($internal_payment_id);
                    break;

                case "V014":
                    // Günsonu yapılmamış işlemler bu hata kodunu iletir ve direkt ana işlem iptal olarak gönderilmelidir.
                    //$this->CancelPaymentBeforeDayBack($internal_payment_id, $bank_payment_id, $ShopCode, $UserCode, $UserPass, $url);
                    break;

                default:
                    // iade cidden başarısız...
                    //$this->SetRefundToPayment1($internal_payment_id);
                    break;
            }
            // TODO: Iade maalesef başarısız :(
        }
    }

    public function CancelPaymentBeforeDayBack($internal_payment_id, $bank_payment_id, $ShopCode, $UserCode, $UserPass, $url){
        $data = "".
            //Kurum Kodu
            "ShopCode=".$ShopCode."&".
            //Üye işyeri numarası
            "UserCode=".$UserCode."&".
            //Kullanıcı Kodu
            "UserPass=".$UserPass."&".
            //Kullanıcı Şifre
            "orgOrderId=".$bank_payment_id."&".
            // İşlem  Sipariş numarası
            "SecureType=NonSecure&".
            //Güvenlik tipi
            "TxnType=Void&".
            //Para Birimi
            "Lang=TR&";
        //Dil bilgisi
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
        curl_setopt($ch, CURLOPT_SSLVERSION, 6);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 90);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $result = curl_exec($ch);

        //print_r($result);


        if (curl_errno($ch)) {
            print curl_error($ch);
        } else {
            curl_close($ch);
        }

        foreach (explode(";;", $result) as $key => $value)
        {
            $data = explode("=", $value);
            $datakey = $data[0];
            $dataval = $data[1];

            $rdata[$datakey] = $dataval;
        }

        $ld_cancel_code  = $rdata["ProcReturnCode"];
        $response_msg   = $rdata["ErrorMessage"];

        if ($ld_cancel_code == "00"){
            $this->SetRefundToPayment1($internal_payment_id);
        }
        else{
            die("BIG ERROR PLEASE CALL THE CODER RIGHT NOW! 0x4588795446845124845121541245");
        }
    }

    public function SetRefundToPayment1($internal_payment_id){
        \DATABASE\FFDatabase::cfun()->update("payment_requests", [["status","refunded"]])->where("id", $internal_payment_id)->run();
    }
}