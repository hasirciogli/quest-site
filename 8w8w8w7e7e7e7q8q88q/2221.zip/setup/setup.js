
var animation_runnable = true;

var animation_text_state = 2;

function TitleAnimation(new_text) {
    var curr_text = document.getElementById("title-animation-text").innerHTML;

    var stateinteger = curr_text.length - 1;

    var animation_state = 1;

    var animationResut = setInterval(() => {
        if (animation_state == 1)
        {
            var new_string = curr_text.substring(0, stateinteger);


            document.getElementById("title-animation-text").innerHTML = new_string;

            if (document.getElementById("title-animation-text").innerHTML == "")
            {
                animation_state = 2;
                stateinteger = 1;
            }
            else{
                stateinteger--;
            }
        }
        else{
            var new_string = new_text.substring(0, stateinteger);


            document.getElementById("title-animation-text").innerHTML = new_string;

            if (document.getElementById("title-animation-text").innerHTML == new_text)
            {
                clearInterval(animationResut);
                animation_runnable = true;
            }
            else{
                stateinteger++;
            }
        }
    }, 10);
}

$(document).ready(() => {
    setInterval(() => {
        if (animation_runnable){
            animation_runnable = false;

            switch (animation_text_state)
            {
                case 1:
                    TitleAnimation("Kuruluma başlamak ister misin ?");
                    animation_text_state++;
                    break;
                case 2:
                    TitleAnimation("Veritabanı bilgilerini gir");
                    animation_text_state++;
                    break;
                case 3:
                    TitleAnimation("Admin hesabını oluştur");
                    animation_text_state++;
                    break;
                case 4:
                    TitleAnimation("Mail bilgilerini gir");
                    animation_text_state++;
                    break;
                case 5:
                    TitleAnimation("Panel otomatik olarak hazırlansın");
                    animation_text_state++;
                    break;
                case 6:
                    TitleAnimation("Nerdeyse tüm bankalarla hizmetimiz var");
                    animation_text_state++;
                    break;
                case 7:
                    animation_text_state = 1;
                    TitleAnimation("Unutma H-Tahsilat en iyisi :)");
                    break;
            }
        }
    }, 5000);
});

$(document).ready(() => {
    $("#ss1-database-verify-button").click(() => {
        $("#ss1-database-verify-button").prop("disabled", true);

        var database_host       = $("#ss1-database-host").val();
        var database_name       = $("#ss1-database-name").val();
        var database_username   = $("#ss1-database-user").val();
        var database_password   = $("#ss1-database-password").val();

        $.ajax({
            url: "./setup_states/config.php",
            type: "POST",
            data: {
                "db-host": database_host,
                "db-name": database_name,
                "db-user": database_username,
                "db-pass": database_password
            },
            success: (data, status) => {
                if (data == "connection-success")
                {
                    $("#setup-state-1").fadeOut("1000");
                    setTimeout(() => {
                        $("#setup-state-2").fadeIn("1000");
                    }, 1100);
                }
                else if (data = "connection-failed"){
                }
                $("#ss1-database-verify-button").prop("disabled", false);
            }
        });

    });
});