<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://cdn.tailwindcss.com?plugins=forms,typography,aspect-ratio,line-clamp"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="./setup.js"></script>
    <title>H-Tahsilat Kurulum Ekranı</title>
</head>
<body class="w-full min-h-screen bg-gradient-to-br from-pink-400 to-purple-600">

<div class="container min-h-screen mx-auto flex items-center justify-center">
    <div class="w-full flex flex-col md:w-[600px] rounded-md mx-auto h-[400px] bg-slate-100">
        <div class="flex w-full h-[60px] items-center justify-center">
            <div id="title-animation-text" class="font-bold text-gray-700 text-2xl">Kuruluma başlamak ister misin ?</div>
        </div>

        <div class="flex w-full h-full">
            <div class="block w-full h-full" id="setup-state-1">
                <div class="flex flex-col items-center justify-center w-full h-full">
                    <h1 class="text-xl">Veritabanı Konfigürasyonu</h1>
                    <input type="text" class="mt-3 w-8/12" id="ss1-database-host"       placeholder="db-host: locahost">
                    <input type="text" class="mt-3 w-8/12" id="ss1-database-name"       placeholder="db-name: htahsilat">
                    <input type="text" class="mt-3 w-8/12" id="ss1-database-user"       placeholder="db-user: root">
                    <input type="text" class="mt-3 w-8/12" id="ss1-database-password"   placeholder="db-password: *****">
                    <button id="ss1-database-verify-button" class="h-10 mt-3 w-8/12 bg-blue-600 hover:bg-blue-800 duration-200 disabled:bg-slate-600 ease-in-out font-bold text-white text-md">Bilgileri Kaydet</button>
                </div>
            </div>

            <div class="hidden w-full h-full" id="setup-state-2">
                <div class="flex flex-col items-center justify-center w-full h-full">
                    <h1 class="text-xl">Admin Hesabı Oluşturulması</h1>
                    <input type="text" class="mt-3 w-8/12" id="ss1-database-host"       placeholder="admin: email">
                    <input type="text" class="mt-3 w-8/12" id="ss1-database-name"       placeholder="admin: username">
                    <input type="text" class="mt-3 w-8/12" id="ss1-database-user"       placeholder="admin: password">
                    <button id="ss1-database-verify-button" class="h-10 mt-3 w-8/12 bg-blue-600 hover:bg-blue-800 duration-200 disabled:bg-slate-600 ease-in-out font-bold text-white text-md">Bilgileri Kaydet</button>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>