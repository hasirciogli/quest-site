SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


CREATE TABLE `data_log` (
                            `id` int(11) NOT NULL,
                            `header` varchar(255) NOT NULL,
                            `body` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


CREATE TABLE `payment_gates` (
                                 `gate_id` int(11) NOT NULL,
                                 `bank_name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
                                 `status` enum('active','passive') NOT NULL DEFAULT 'passive',
                                 `image_link` text DEFAULT NULL,
                                 `param_keys` text DEFAULT NULL,
                                 `req_keys` text DEFAULT NULL,
                                 `bank_id` int(11) NOT NULL,
                                 `test_mode` tinyint(1) DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



INSERT INTO `payment_gates` (`gate_id`, `bank_name`, `status`, `image_link`, `param_keys`, `req_keys`, `bank_id`, `test_mode`) VALUES
                                                                                                                                   (1, 'AKBANK', 'passive', NULL, '{\"merchant_id\":\"1\",\"merchant_pass\":\"2\",\"user_id\":\"1\",\"user_pass\":\"4\"}', '[\"merchant_id\",\"merchant_pass\",\"user_id\",\"user_pass\"]', 1, 1),
                                                                                                                                   (2, 'ANADOLUBANK', 'passive', NULL, NULL, NULL, 2, 1),
                                                                                                                                   (3, 'DENIZBANK', 'active', NULL, '{\"shop_code\":\"7278\",\"merchant_pass\":\"4VE6Z\"}', '[\"shop_code\", \"merchant_pass\"]', 3, 0),
                                                                                                                                   (4, 'ODEA', 'passive', NULL, NULL, NULL, 4, 1),
                                                                                                                                   (5, 'QNB FINANSBANK', 'active', NULL, '{\"merchant_id\":\"085300000009704\",\"merchant_pass\":\"12345678\",\"user_id\":\"QNB_API_KULLANICI_3DPAY\",\"user_pass\":\"UcBN0\"}', '[\"merchant_id\",\"merchant_pass\",\"user_id\",\"user_pass\"]', 5, 1),
                                                                                                                                   (6, 'ING BANK', 'active', NULL, '{\"client_id\":\"150270657\",\"store_key\":\"IN506007\"}', '[\"client_id\", \"store_key\"]', 10, 0),
                                                                                                                                   (7, 'ŞEKERBANK', 'active', NULL, '{\"client_id\":\"220272373\",\"store_key\":\"SBNK7485\"}', '[\"client_id\", \"store_key\"]', 11, 0),
                                                                                                                                   (8, 'FIBABANKA', 'passive', NULL, NULL, '', 6, 1),
                                                                                                                                   (9, 'GARANTI BANKASI', 'passive', NULL, '{\"terminal_merchant_id\":\"1\",\"terminal_id\":\"2\",\"prov_user_id \":null,\"prov_user_pass\":\"4\",\"garantipay_prov_user_id\":\"2\",\"garantipay_prov_user_pass\":\"6\",\"3d_store_key\":\"7\"}', '[\"terminal_merchant_id\",\"terminal_id\",\"prov_user_id \",\"prov_user_pass\",\"garantipay_prov_user_id\",\"garantipay_prov_user_pass\",\"3d_store_key\"]', 7, 1),
                                                                                                                                   (10, 'HALK BANKASI', 'passive', NULL, 'null', NULL, 8, 1),
                                                                                                                                   (11, 'VAKIFBANK', 'passive', NULL, NULL, NULL, 9, 1);



CREATE TABLE `payment_requests` (
                                    `id` bigint(20) UNSIGNED NOT NULL,
                                    `price` double(12,2) NOT NULL DEFAULT 1.00,
                                    `currency_unit` int(11) NOT NULL DEFAULT 949,
                                    `ip_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
                                    `status` enum('confirmed','waiting','refused','cancelled','blocked','no action') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no action',
                                    `created_at` timestamp NULL DEFAULT current_timestamp(),
                                    `updated_at` timestamp NULL DEFAULT NULL,
                                    `balance_status` enum('valid','waiting','blocked') COLLATE utf8mb4_unicode_ci DEFAULT 'waiting',
                                    `x_data` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
                                    `payment_type` enum('link','api','bank') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'link',
                                    `owner_user_id` int(11) DEFAULT 1,
                                    `response_data` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `bank_id` int(11) NOT NULL DEFAULT 1,
                                    `is_silent` tinyint(1) NOT NULL DEFAULT 0,
                                    `created_at_odate` date DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `sessions` (
                            `id` int(11) NOT NULL,
                            `session_key` varchar(255) NOT NULL,
                            `expiry` int(11) NOT NULL DEFAULT 0,
                            `data` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


CREATE TABLE `site_data` (
                             `maintenance_mode` int(11) NOT NULL DEFAULT 1,
                             `default_payment_gate` int(11) NOT NULL DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


INSERT INTO `site_data` (`maintenance_mode`, `default_payment_gate`) VALUES
    (0, 0);

-- --------------------------------------------------------



CREATE TABLE `users` (
                         `id` int(12) NOT NULL,
                         `name` varchar(255) NOT NULL,
                         `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                         `birthday` date DEFAULT NULL,
                         `email_state` enum('confirmed','waiting','sent','blocked') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'waiting',
                         `confirmed_balance` double(12,2) NOT NULL DEFAULT 0.00,
                         `unconfirmed_balance` double(15,2) NOT NULL DEFAULT 0.00,
                         `type` enum('admin','user') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
                         `password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                         `created_at` timestamp NULL DEFAULT NULL,
                         `updated_at` timestamp NULL DEFAULT NULL,
                         `api_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                         `api_secret` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                         `percent_per_payment` double NOT NULL DEFAULT 2.99,
                         `cost_per_payment` double NOT NULL DEFAULT 0.29,
                         `mail_conf_key` varchar(255) NOT NULL,
                         `website_limit` int(11) NOT NULL DEFAULT 10,
                         `phone` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `birthday`, `email_state`, `confirmed_balance`, `unconfirmed_balance`, `type`, `password`, `created_at`, `updated_at`, `api_key`, `api_secret`, `percent_per_payment`, `cost_per_payment`, `mail_conf_key`, `website_limit`, `phone`) VALUES
    (1, 'Ben Bir Adminim', 'admin@domain.com', '1994-07-28', 'confirmed', 0.00, 541.00, 'admin', 'EoG6k0Uase6RgWBKYYh+eg==', NULL, NULL, '8wxl9hpzwt3s2w8kszpmxt06srz3bhlpynj1p3gb7z1m63bfvcsflv3deaso0o8z4emyv6rg30k6ckk58um5uchoaq7tf56kas98ycbso582b99pf1kgrw5v33oih2h0', 'oc9z14ztjz68zbhf9urhhwq5apukudakhwum6ur0tj04r4z22ymprv9smsmnqtxuu13wpbm9eek6rozlb9amu5zhrsltei8r0kh2p2uf0ds9sgh1z72ypjqc35b6p2fx', 2.99, 0.29, '', 10, '+905556668877');

-- --------------------------------------------------------

--
-- Table structure for table `websites`
--

CREATE TABLE `websites` (
                            `id` int(12) NOT NULL,
                            `domain` varchar(255) NOT NULL,
                            `owner_id` int(11) NOT NULL,
                            `status` enum('waiting','refused','active','blocked','owner_check') NOT NULL DEFAULT 'owner_check',
                            `review_request_count` int(11) NOT NULL DEFAULT 1,
                            `callback_url` text DEFAULT NULL,
                            `owner_check_count` int(11) NOT NULL DEFAULT 1,
                            `site_ssl` enum('yes','no') NOT NULL DEFAULT 'no'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

ALTER TABLE `data_log`
    ADD PRIMARY KEY (`id`);

ALTER TABLE `payment_gates`
    ADD PRIMARY KEY (`gate_id`),
    ADD UNIQUE KEY `payment_gates_bank_id_uindex` (`bank_id`);


ALTER TABLE `payment_requests`
    ADD PRIMARY KEY (`id`);


ALTER TABLE `sessions`
    ADD PRIMARY KEY (`id`);


ALTER TABLE `users`
    ADD PRIMARY KEY (`id`),
    ADD UNIQUE KEY `users_email_unique` (`email`);


ALTER TABLE `websites`
    ADD PRIMARY KEY (`id`);



ALTER TABLE `data_log`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;



ALTER TABLE `payment_gates`
    MODIFY `gate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;



ALTER TABLE `payment_requests`
    MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;



ALTER TABLE `sessions`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;



ALTER TABLE `users`
    MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;



ALTER TABLE `websites`
    MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;