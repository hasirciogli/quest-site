<?php

if (!isset($_POST))
    return;

$db_host        = @isset($_POST["db-host"]) ? $_POST["db-host"] : "";
$db_name        = @isset($_POST["db-name"]) ? $_POST["db-name"] : "";
$db_username    = @isset($_POST["db-user"]) ? $_POST["db-user"] : "";
$db_password    = @isset($_POST["db-pass"]) ? $_POST["db-pass"] : "";


try {
    @$connection = new PDO("mysql:host=" . $db_host . ";dbname=" . $db_name . ";charset=utf8", $db_username, $db_password);
}catch(Exception $e){
    echo "connection-failed";
    return;
}

if ($connection)
{
    file_put_contents("./../../app/Configs/Config.php",
        '<?php

define("configs_site_rootfolder"    , $_SERVER["DOCUMENT_ROOT"]);


define("configs_db_host"            , "' . $db_host . '");
define("configs_db_username"        , "' . $db_username . '");
define("configs_db_name"            , "' . $db_name . '");
define("configs_db_password"        , "' . $db_password . '");

define("configs_mail_host"          , "mail-host");
define("configs_mail_username"      , "mail-username");
define("configs_mail_from"          , "mail-from");
define("configs_mail_sender"        , "mail-sender");
define("configs_mail_port"          , 587);
define("configs_mail_password"       , "mail-password");




define("configs_api_prefix"       , "api");


define("framework_is_debug_mode"       , false);

?>');

    //$v = $connection->prepare(file_get_contents("./../sqls/req.sql"));
    //$v->execute([]);

    echo "connection-success";
    return;
}
else
{
    echo "connection-failed";
    return;
}

?>