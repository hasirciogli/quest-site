<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://cdn.tailwindcss.com?plugins=forms,typography,aspect-ratio,line-clamp"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Golos+Text:wght@400;500;600;700;800;900&family=Nunito:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&family=Quicksand:wght@300;400;500;600;700&display=swap');
    </style>
    <title>HÜBA Fide</title>

    <style>
        .fffonts-nunito{
            font-family: 'Nunito', sans-serif;
        }

        .fffonts-qsand{
            font-family: 'Quicksand', sans-serif;
        }

        .fffonts-golostext{
            font-family: 'Golos Text', sans-serif;
        }
    </style>
</head>
<body>

<nav class="w-full border-b border-b-green-400">
    <div class="flex flex-row mx-auto container h-14 md:h-[100px] bg-white">
        <div class="flex flex-row items-center p-3 w-full md:w-[300px] h-full justify-center md:justify-start">
            <div class="rounded-full w-10 h-10 bg-green-400 shadow-md">
                <img src="https://i.ibb.co/k3YDvRZ/istockphoto-1164153261-612x612-removebg-preview.png" class="w-full h-full" alt="hüba fide logo designed by mustafa hasırcıoğlu">
            </div>
            <div class="flex h-full pt-2 pl-3 fffonts-nunito font-bold text-2xl items-center">
                <span class="text-green-400 pr-1">HÜBA</span>FİDE
            </div>
        </div>

        <div class="hidden md:flex flex justify-end w-full h-[20] items-center fffonts-golostext">
            <div class="flex items-center flex-row">
                <ion-icon name="time-outline" class="text-3xl text-green-500 p-3"></ion-icon>
                <div>
                    <div>İletişim saatleri</div>
                    <div><strong>Her gün 09:00 - 22:00 arası</strong></div>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="h-0 hidden md:flex">
    <div class="relative top-[-20px] mx-auto container h-10">
        <div class="flex flex-row mx-auto w-11/12 bg-gray-800 h-[40px] rounded-md text-xs lg:text-sm text-white fffonts-qsand overflow-hidden shadow">
            <div class="flex items-center justify-center w-full border-r border-r-white hover:cursor-pointer hover:bg-green-500 duration-300">Hakkımızda</div>
            <div class="flex items-center justify-center w-full border-r border-r-white hover:cursor-pointer hover:bg-green-500 duration-300">Ürünlerimiz</div>
            <div class="flex items-center justify-center w-full border-r border-r-white hover:cursor-pointer hover:bg-green-500 duration-300">İletişim</div>
            <a href="tel:+905300364177" class="flex items-center justify-center min-w-[200px] lg:min-w-[400px] bg-green-500 font-semibold">
                <ion-icon name="call-outline" class="text-2xl mr-2"></ion-icon>
                +905300364177
            </a>
        </div>
    </div>
</div>


<div class="bg-red-600 h-screen">
    <div class="w-full h-full overflow-hidden rounded-md bg-blue-600 bg-[url('https://cdn.iha.com.tr/Contents/pool_file/2021/40/71966_aw435164-03.jpg')] bg-center bg-no-repeat bg-origin-content bg-cover"></div>
</div>


<div class="w-full">
    <div class="flex flex-col md:flex-row mx-auto container">

        <div class="w-full md:w-6/12 h-full p-0 md:p-5">
            <div class="flex flex-col min-h-[600px] h-[600px] p-2 md:p-5">
                <div class="flex flex-col w-full h-full bg-gray-100 border border-slate-200 shadow-lg p-3 pb-10 md:p-6 rounded-lg">
                    <h1 class="text-green-500 font-semibold text-lg fffonts-nunito">Merhaba Hocam</h1>
                    <div class="mt-3 text-2xl md:text-5xl font-semibold fffonts-golostext">Burası başlık olacak</div>
                    <p class="mt-6 text-sm md:text-md">
                        <span class="pl-5"></span>Lorem ipsum dolor sit amet, consectetur ad
                        ipisicing elit. Deleniti dolor excepturi impedit iure quae qui quo. Amet
                        animi aut, commodi consequuntur culpa dolor expedita harum in itaque mole
                        stiae tempora temporibus.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo no
                        strum quas recusandae repellendus veritatis! Animi assumenda, beatae dol
                        oribus facilis harum laboriosam, molestias quae quasi quibusdam reiciendis
                        repudiandae temporibus tenetur veritatis.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. A alias ani
                        mi aspernatur aut commodi eaque facere fuga ipsa maxime mollitia numquam
                        optio, pariatur ratione recusandae tempore temporibus unde vel veritatis.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti dol
                        or excepturi impedit iure quae qui quo. Amet animi aut, commodi consequu
                    </p>
                </div>
                <div class="h-0">
                    <button class="bg-green-500 relative text-md text-white font-semibold fffonts-qsand h-[40px] w-[150px] rounded-sm shadow-lg top-[-20px] ml-5 hover:bg-green-600 duration-300">İletişim</button>
                </div>
            </div>
        </div>

        <div class="w-full md:w-7/12 h-full p-0 md:p-5 mt-5 md:mt-0">
            <div class="flex flex-col min-h-[600px] h-[900px] md:h-[600px] p-2 md:p-5">
                <div class="flex flex-col w-full h-full p-3 pb-10 md:p-6 rounded-lg gap-4">

                    <div class="flex flex-col md:flex-row w-full h-full gap-4">
                        <div class="flex items-center justify-center w-full h-full rounded-md">
1
                        </div>
                        <div class="flex items-center justify-center w-full h-full rounded-md">
2
                        </div>
                    </div>

                    <div class="flex flex-col md:flex-row w-full h-full gap-4">
                        <div class="flex items-center justify-center w-full h-full rounded-md">
3
                        </div>
                        <div class="flex items-center justify-center w-full h-full rounded-md">
4
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>