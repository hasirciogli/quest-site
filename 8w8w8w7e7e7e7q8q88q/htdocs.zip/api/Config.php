<?php

define("configs_site_rootfolder"    , $_SERVER["DOCUMENT_ROOT"]);

define("configs_db_host"            , "localhost");
define("configs_db_username"        , "root");
define("configs_db_name"            , "anonimol.com");
define("configs_db_password"        , "1234");

?>